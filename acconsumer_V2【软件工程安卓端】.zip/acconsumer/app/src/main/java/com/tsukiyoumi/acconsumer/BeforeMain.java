package com.tsukiyoumi.acconsumer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import org.json.JSONException;

public class BeforeMain extends AppCompatActivity {
    public EditText editIP;
    public EditText editPort;
    public EditText editRoomId;
    public EditText editTemp;
    public LinearLayout okBtn;

    private SharedPreferences mSharedPreferences;

    public static final String HISTORY_FLAG = "flag";
    public static final String HISTORY_IP = "ip";
    public static final String HISTORY_PORT = "port";
    public static final String HISTORY_ROOMID = "roomid";
    public static final String HISTORY_TEMP = "temp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_before_main);

        editIP = findViewById(R.id.editIP);
        editPort = findViewById(R.id.editPort);
        editRoomId = findViewById(R.id.editRoomId);
        editTemp = findViewById(R.id.editTemp);
        okBtn = findViewById(R.id.okBtn);

        mSharedPreferences = getSharedPreferences("settings", Context.MODE_PRIVATE);
        boolean haveHistory = mSharedPreferences.getBoolean(HISTORY_FLAG, false);

        if (haveHistory) {
            editIP.setText(mSharedPreferences.getString(HISTORY_IP, "127.0.0.1"));
            editPort.setText(mSharedPreferences.getString(HISTORY_PORT, "9678"));
            editRoomId.setText(mSharedPreferences.getString(HISTORY_ROOMID, "1"));
            editTemp.setText(mSharedPreferences.getString(HISTORY_TEMP, "28"));
        }
    }

    public void ok_onclick(View View) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putBoolean(HISTORY_FLAG, true);
        editor.putString(HISTORY_IP, editIP.getText().toString());
        editor.putString(HISTORY_PORT, editPort.getText().toString());
        editor.putString(HISTORY_ROOMID, editRoomId.getText().toString());
        editor.putString(HISTORY_TEMP, editTemp.getText().toString());
        editor.commit();

        startActivity(new Intent(BeforeMain.this, MainActivity.class));
    }
}