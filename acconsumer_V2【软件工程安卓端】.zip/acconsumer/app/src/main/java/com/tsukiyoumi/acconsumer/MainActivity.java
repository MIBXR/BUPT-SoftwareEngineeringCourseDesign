package com.tsukiyoumi.acconsumer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    public JWebSocketClient client;

    public static TextView title;
    public static TextView CurTemp;
    public static TextView TarTemp;
    public static TextView mode;
    public static TextView fan;
    public static TextView feeRate;
    public static TextView feeCur;
    public static TextView feeTol;
    public static ImageView poweron;
    public static ImageView poweroff;
    public static ImageView fanup;
    public static ImageView fandown;
    public static ImageView tempup;
    public static ImageView tempdown;

    final static public int MSG_TYPE_TURNON = 0;
    final static public int MSG_TYPE_ENTERROOM = 1;
    final static public int MSG_TYPE_CHANGEWIND = 2;
    final static public int MSG_TYPE_CHANGETEMP = 3;
    final static public int MSG_TYPE_CHANGEMODE = 4;
    final static public int MSG_TYPE_SHOWCURRENTMONEY = 5;
    final static public int MSG_TYPE_TURNOFF = 13;
    final static public int MSG_TYPE_REWARM = 14;

    final static public int FANSPEED_LOWWIND = 1;
    final static public int FANSPEED_MIDDLEWIND = 2;
    final static public int FANSPEED_HIGHWIND = 3;

    final static public int MODE_COOL = 1;
    final static public int MODE_WARM = 2;
    final static public int MODE_OFF = 3;

    final static public int STATE_RUNNING = 100;
    final static public int STATE_PREEMPTED = 101;
    final static public int STATE_DONE = 102;

    final static public double REWARM_DELTA = 0.2;
    final static public int REWARM_FREQ = 2000;
    final static public double REWARM_MAX = 0.999999;

    private static int RoomId = 1;
    private static String UserId;
    private static int mMode;
    private static double mCurrentTemp = 28;
    private static int mTargetTemp;
    private static int mFanSpeed;

    private static double tempBeforeRewarm;

    private static int mModeR;
    private static int mTargetTempR;
    private static int mFanSpeedR;

    private static int minTemp = 0;
    private static int maxTemp = 100;

    private static double mCurrentFee = 0.00;
    private static double mTotalFee = 0.00;
    private static double mRateFee = 0.00;

    private static int mACState = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String IP = getBaseContext().getSharedPreferences("settings", Context.MODE_PRIVATE).getString(BeforeMain.HISTORY_IP, "127.0.0.1");
        String port = getBaseContext().getSharedPreferences("settings", Context.MODE_PRIVATE).getString(BeforeMain.HISTORY_PORT, "9678");
        RoomId = Integer.valueOf(getBaseContext().getSharedPreferences("settings", Context.MODE_PRIVATE).getString(BeforeMain.HISTORY_ROOMID, "1")).intValue();
        mCurrentTemp = Integer.valueOf(getBaseContext().getSharedPreferences("settings", Context.MODE_PRIVATE).getString(BeforeMain.HISTORY_TEMP, "27")).intValue();

        // socket创建与连接
        URI uri = URI.create("ws://" + IP + ":" + port);
        client = new JWebSocketClient(uri) {
            @Override
            public void onMessage(String message) {
                //message就是接收到的消息
                Log.e("JWebSClientService", message);
                try {
                    JSONObject jsonM = new JSONObject(message);
                    int type = jsonM.getInt("MsgType");
                    switch (type) {
                        case MSG_TYPE_TURNON:
                            if (jsonM.has("Mode") && jsonM.has("WindSpeed") && jsonM.has("TargetTemp") && jsonM.has("FeeRate")) {
                                mMode = Integer.valueOf(jsonM.getString("Mode"));
                                mFanSpeed = Integer.valueOf(jsonM.getString("WindSpeed"));
                                mTargetTemp = Integer.valueOf(jsonM.getString("TargetTemp"));
                                mRateFee = Double.valueOf(jsonM.getString("FeeRate"));
                                mhandler.sendEmptyMessage(MSG_TYPE_TURNON);
                            }
                            break;
                        case MSG_TYPE_ENTERROOM:
                            if (jsonM.has("UserId")) {
                                UserId = jsonM.getString("UserId");
                                mhandler.sendEmptyMessage(MSG_TYPE_ENTERROOM);
                            }
                            break;
                        case MSG_TYPE_CHANGEWIND:
                            if (jsonM.has("FeeRate")) {
                                mFanSpeed = mFanSpeedR;
                                mRateFee = Double.valueOf(jsonM.getString("FeeRate"));
                                mhandler.sendEmptyMessage(MSG_TYPE_CHANGEWIND);
                            }
                            break;
                        case MSG_TYPE_CHANGETEMP:
                            if (jsonM.has("Ack")) {
                                int ack = Integer.valueOf(jsonM.getString("Ack"));
                                if (ack == 1) {
                                    mTargetTemp = mTargetTempR;
                                    mhandler.sendEmptyMessage(MSG_TYPE_CHANGETEMP);
                                }
                                else {
                                    mTargetTempR = mTargetTemp;
                                    Toast.makeText(getBaseContext(),"温度超出调节范围!",Toast.LENGTH_SHORT).show();
                                }
                            }
                            break;
                        case MSG_TYPE_TURNOFF:
                            if (jsonM.has("Money")) {
                                mCurrentFee = 0.00;
                                double tmp = Double.valueOf(jsonM.getString("Money"));
                                mTotalFee += tmp;
                                mhandler.sendEmptyMessage(MSG_TYPE_TURNOFF);
                            }
                            break;
                        case MSG_TYPE_SHOWCURRENTMONEY:
                            if (jsonM.has("Money") && jsonM.has("RoomTemp")) {
                                mCurrentFee = Double.valueOf(jsonM.getString("Money"));
                                mCurrentTemp = Double.valueOf(jsonM.getString("RoomTemp"));
                                mhandler.sendEmptyMessage(MSG_TYPE_SHOWCURRENTMONEY);
                            }
                            break;
                        case STATE_RUNNING:
                            mACState = STATE_RUNNING;
                            send_state_after_schedual(mACState);
                            mhandler.sendEmptyMessage(STATE_RUNNING);
                            break;
                        case STATE_PREEMPTED:
                            mACState = STATE_PREEMPTED;
                            send_state_after_schedual(mACState);
                            mhandler.sendEmptyMessage(STATE_PREEMPTED);
                            break;
                        case STATE_DONE:
                            mACState = STATE_DONE;
                            send_state_after_schedual(mACState);
                            mhandler.sendEmptyMessage(STATE_DONE);
                            start_rewarm();
                            break;
                        default:
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        try {
            client.connectBlocking();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (client != null && client.isOpen()) {
            JSONObject jsonM = new JSONObject();
            try {
                jsonM.put("MsgType", MSG_TYPE_ENTERROOM);
                jsonM.put("RoomId", "" + RoomId);
                Log.d("send" ,jsonM.toString());
                client.send(jsonM.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        // 寻找控件
        title = findViewById(R.id.title);
        CurTemp = findViewById(R.id.CurTemp);
        TarTemp = findViewById(R.id.TarTemp);
        mode = findViewById(R.id.mode);
        fan = findViewById(R.id.fan);
        feeRate = findViewById(R.id.feeRate);
        feeCur = findViewById(R.id.feeCur);
        feeTol = findViewById(R.id.feeTot);
        poweron = findViewById(R.id.poweron);
        poweroff = findViewById(R.id.poweroff);
        fanup = findViewById(R.id.Windup);
        fandown = findViewById(R.id.Winddown);
        tempup = findViewById(R.id.Tempup);
        tempdown = findViewById(R.id.Tempdown);


    }

    public static Handler mhandler = new Handler(Looper.myLooper()) {
        public String getWindStr(int FanSpeed) {
            switch(FanSpeed) {
                case FANSPEED_LOWWIND:
                    return "低";
                case FANSPEED_MIDDLEWIND:
                    return "中";
                case FANSPEED_HIGHWIND:
                    return "高";
                default:
                    return "error";
            }
        }

        public String getModeStr(int Mode) {
            switch(Mode) {
                case MODE_COOL:
                    return "制冷";
                case MODE_WARM:
                    return "制热";
                case MODE_OFF:
                    return "关闭";
                default:
                    return "error";
            }
        }
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_TYPE_TURNON:
                    title.setText("空调遥控器-等待中");
                    mode.setText(getModeStr(mMode));
                    CurTemp.setText(String.format("%.2f", mCurrentTemp));
                    TarTemp.setText(String.format("%d", mTargetTemp));
                    fan.setText(getWindStr(mFanSpeed));
                    feeRate.setText(String.format("%.2f", mRateFee));
                    feeCur.setText(String.format("%.2f", mCurrentFee));
                    feeTol.setText(String.format("%.2f", mTotalFee));
//                    Toast.makeText(getBaseContext(),"handler收到msg, what = 0", Toast.LENGTH_SHORT).show();
                    break;
                case MSG_TYPE_ENTERROOM:
                    break;
                case MSG_TYPE_CHANGEWIND:
                    fan.setText(getWindStr(mFanSpeed));
                    break;
                case MSG_TYPE_CHANGETEMP:
                    TarTemp.setText(String.format("%d", mTargetTemp));
                    break;
                case MSG_TYPE_TURNOFF:
                    title.setText("空调遥控器-关机");
                    mode.setText("关");
                    CurTemp.setText("OFF");
                    TarTemp.setText("OFF");
                    fan.setText("关");
                    feeRate.setText("0.00");
                    feeCur.setText("0.00");
                    feeTol.setText(String.format("%.2f", mTotalFee));
                    break;
                case MSG_TYPE_SHOWCURRENTMONEY:
                    CurTemp.setText(String.format("%.2f", mCurrentTemp));
                    feeCur.setText(String.format("%.2f", mCurrentFee));
                    break;
                case STATE_RUNNING:
                    title.setText("空调遥控器-服务中");
                    break;
                case STATE_PREEMPTED:
                    title.setText("空调遥控器-等待中");
                    break;
                case STATE_DONE:
                    title.setText("空调遥控器-服务完成");
                    break;
                case MSG_TYPE_REWARM:
                    CurTemp.setText(String.format("%.2f", mCurrentTemp));
                    break;
                default:
                    break;
            }
        }
    };
    private final Timer timer = new Timer();
    private final TimerTask task = new TimerTask() {
        @Override
        public void run() {
            if (mMode == MODE_COOL) {
                mCurrentTemp = mCurrentTemp + REWARM_DELTA;
            }
            else {
                mCurrentTemp = mCurrentTemp - REWARM_DELTA;
            }
            JSONObject jsonM = new JSONObject();
            try {
                jsonM.put("MsgType", MSG_TYPE_REWARM);
                jsonM.put("RoomId", "" + RoomId);
                jsonM.put("RoomTemp", "" + mCurrentTemp);
                Log.d("send" ,jsonM.toString());
                client.send(jsonM.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (Math.abs(mCurrentTemp - tempBeforeRewarm) < REWARM_MAX) {
                mhandler.sendEmptyMessage(MSG_TYPE_REWARM);
            }
            else {
                mhandler.sendEmptyMessage(MSG_TYPE_REWARM);
                timer.cancel();
                try {
                    jsonM.put("MsgType", MSG_TYPE_TURNON);
                    jsonM.put("RoomId", "" + RoomId);
                    jsonM.put("UserId", UserId);
                    jsonM.put("RoomTemp", "" + mCurrentTemp);
                    Log.d("send" ,jsonM.toString());
                    client.send(jsonM.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    };
    public void start_rewarm() {
        tempBeforeRewarm = mCurrentTemp;
        timer.schedule(task,0,REWARM_FREQ);
    }

    public void send_state_after_schedual(int State) throws JSONException {
        JSONObject jsonM = new JSONObject();
        jsonM.put("MsgType", State);
        jsonM.put("RoomId", "" + RoomId);
        jsonM.put("RoomTemp", "" + mCurrentTemp);
        Log.d("send" ,jsonM.toString());
        client.send(jsonM.toString());
    }

    public void poweron_onclick(View View) throws JSONException {
        JSONObject jsonM = new JSONObject();
        jsonM.put("MsgType", MSG_TYPE_TURNON);
        jsonM.put("RoomId", "" + RoomId);
        jsonM.put("UserId", UserId);
        jsonM.put("RoomTemp", "" + mCurrentTemp);
        Log.d("send" ,jsonM.toString());
        client.send(jsonM.toString());
    }
    public void poweroff_onclick(View View) throws JSONException {
        JSONObject jsonM = new JSONObject();
        jsonM.put("MsgType", MSG_TYPE_TURNOFF);
        jsonM.put("RoomId", "" + RoomId);
        jsonM.put("UserId", UserId);
        Log.d("send" ,jsonM.toString());
        client.send(jsonM.toString());
    }
    public void Windup_onclick(View View) throws JSONException {
        if (mFanSpeed + 1 <= FANSPEED_HIGHWIND) {
            mFanSpeedR = mFanSpeed + 1;
            JSONObject jsonM = new JSONObject();
            jsonM.put("MsgType", MSG_TYPE_CHANGEWIND);
            jsonM.put("RoomId", "" + RoomId);
            jsonM.put("UserId", UserId);
            jsonM.put("WindSpeed", "" + mFanSpeedR);
            Log.d("send" ,jsonM.toString());
            client.send(jsonM.toString());
        }
        else {
            Toast.makeText(getBaseContext(),"风速超出调节范围!",Toast.LENGTH_SHORT).show();
        }
    }
    public void Winddown_onclick(View View) throws JSONException {
        if (mFanSpeed - 1 >= FANSPEED_LOWWIND) {
            mFanSpeedR = mFanSpeed - 1;
            JSONObject jsonM = new JSONObject();
            jsonM.put("MsgType", MSG_TYPE_CHANGEWIND);
            jsonM.put("RoomId", "" + RoomId);
            jsonM.put("UserId", UserId);
            jsonM.put("WindSpeed", "" + mFanSpeedR);
            Log.d("send" ,jsonM.toString());
            client.send(jsonM.toString());
        }
        else {
            Toast.makeText(getBaseContext(),"风速超出调节范围!",Toast.LENGTH_SHORT).show();
        }
    }
    public void Tempup_onclick(View View) throws JSONException {
        if (mTargetTemp + 1 <= maxTemp) {
            mTargetTempR = mTargetTemp + 1;
            JSONObject jsonM = new JSONObject();
            jsonM.put("MsgType", MSG_TYPE_CHANGETEMP);
            jsonM.put("RoomId", "" + RoomId);
            jsonM.put("UserId", UserId);
            jsonM.put("TargetTemp", "" + mTargetTempR);
            Log.d("send" ,jsonM.toString());
            client.send(jsonM.toString());
        }
        else {
            Toast.makeText(getBaseContext(),"温度超出调节范围!",Toast.LENGTH_SHORT).show();
        }
    }
    public void Tempdown_onclick(View View) throws JSONException {
        if (mTargetTemp - 1 >= minTemp) {
            mTargetTempR = mTargetTemp - 1;
            JSONObject jsonM = new JSONObject();
            jsonM.put("MsgType", MSG_TYPE_CHANGETEMP);
            jsonM.put("RoomId", "" + RoomId);
            jsonM.put("UserId", UserId);
            jsonM.put("TargetTemp", "" + mTargetTempR);
            Log.d("send" ,jsonM.toString());
            client.send(jsonM.toString());
        }
        else {
            Toast.makeText(getBaseContext(),"温度超出调节范围!",Toast.LENGTH_SHORT).show();
        }
    }
}
