#include "consumer_window.h"
#include "ui_consumer_window.h"

consumer_window::consumer_window(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::consumer_window)
{
    ui->setupUi(this);

    //设定界面初始数值
    setWindowTitle(tr("用户界面"));
    ui->lcdNumber->setDigitCount(5);
    ui->lcdNumber->setMode(QLCDNumber::Dec);
    ui->lcdNumber->setSegmentStyle(QLCDNumber::Flat);
    ui->lcdNumber->setStyleSheet("border: black; color: black; background: silver;");
    ui->lcdNumber_2->setDigitCount(5);
    ui->lcdNumber_2->setMode(QLCDNumber::Dec);
    ui->lcdNumber_2->setSegmentStyle(QLCDNumber::Flat);
    ui->lcdNumber_2->setStyleSheet("border: black; color: black; background: silver;");

//    ui->currentState->setText("关闭");
    ui->currentMode->setText("关闭");
    ui->currentSpeedofwind->setText("关闭");
    ui->lcdNumber->display("OFF");
    ui->lcdNumber_2->display("OFF");
    ui->rateFee->setText("0.00");
    ui->currentFee->setText("0.00");
    ui->totalFee->setText("0.00");
    ui->tempUp->setEnabled(false);
    ui->tempDown->setEnabled(false);
    ui->windUp->setEnabled(false);
    ui->windDown->setEnabled(false);
    ui->close->setEnabled(false);

}

consumer_window::~consumer_window()
{
    delete ui;
}

void consumer_window::onLoggined(double CurrentTemp, int RoomId)
{
    // 服务器连接成功
    ui->roomID->setText(QString::number(RoomId, 10));  // 设定房间号
    ui->lcdNumber_2->display(QString::number(CurrentTemp, 'f',2));  // 设定房间温度
    this->show();
}

void consumer_window::on_PowerOn(int Mode, double CurrentTemp, int TargetTemp, int FanSpeed, double CurrentFee, double TotalFee, double RateFee)
{
    // 开机
    if (Mode != -1)
    {
    ui->tempUp->setEnabled(true);
    ui->tempDown->setEnabled(true);
    ui->windUp->setEnabled(true);
    ui->windDown->setEnabled(true);
    ui->close->setEnabled(true);
    ui->open->setEnabled(false);

//    ui->currentState->setText("等待中");
    ui->currentMode->setText(getModeStr(Mode));
    ui->lcdNumber_2->display(QString::number(CurrentTemp, 'f',2));
    uiTargetTemp = TargetTemp;
    ui->lcdNumber->display(uiTargetTemp);
    uiFanSpeed = FanSpeed;
    ui->currentSpeedofwind->setText(getWindStr(FanSpeed));
    ui->currentFee->setText(QString::number(CurrentFee, 10,2));
    ui->totalFee->setText(QString::number(TotalFee, 10,2));
    ui->rateFee->setText(QString::number(RateFee, 10,2));
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "服务器出现问题，开机失败，您可以稍后再试");
    }
}

void consumer_window::on_RequestState(double CurrentTemp, double CurrentFee, double TotalFee)
{
    // 更新状态
    if (CurrentTemp > 0)
    {
        ui->lcdNumber_2->display(QString::number(CurrentTemp, 'f',2));
        ui->currentFee->setText(QString::number(CurrentFee, 'f', 2));
        ui->totalFee->setText(QString::number(TotalFee, 'f', 2));
    }
    else
    {
        qDebug() << "Error: request state error";
    }
}

void consumer_window::on_ChangeTargetTemp(int TargetTemp)
{
    // 调温
    if (TargetTemp != -1)
    {
        uiTargetTemp = TargetTemp;
        ui->lcdNumber->display(uiTargetTemp);
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "温度超出调节范围");
    }
}

void consumer_window::on_ChangeFanSpeed(double RateFee)
{
    // 调风
    if (RateFee != -1)
    {
        ui->currentSpeedofwind->setText(getWindStr(uiFanSpeed));
        ui->rateFee->setText(QString::number(RateFee, 10,2));
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "服务器出现问题，调节风速失败，您可以稍后再试");
    }
}

void consumer_window::on_RequestRelease(int state)
{
    //
    if (state != -1)
    {
//        ui->currentState->setText(getStateStr(state));
    }
    else
    {
        qDebug() << "Error: state error";
    }
}

void consumer_window::on_RequestTempUp(double CurrentTemp)
{
    //
    if (CurrentTemp > 0)
    {
        ui->lcdNumber_2->display(QString::number(CurrentTemp, 'f',2));
    }
    else
    {
        qDebug() << "Error: request temp up error";
    }
}

void consumer_window::on_PowerOff(double isOK)
{
    // 关机
    if (isOK > 0)
    {
//        ui->currentState->setText("关闭");
        ui->currentMode->setText("关闭");
        ui->currentSpeedofwind->setText("关闭");
        ui->lcdNumber->display("OFF");
        ui->rateFee->setText("0.00");
        ui->currentFee->setText(QString::number(isOK, 'f', 2));
        ui->totalFee->setText(QString::number(isOK, 'f', 2));

        ui->tempUp->setEnabled(false);
        ui->tempDown->setEnabled(false);
        ui->windUp->setEnabled(false);
        ui->windDown->setEnabled(false);
        ui->close->setEnabled(false);
        ui->open->setEnabled(true);
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "服务器出现问题，关机失败，您可以稍后再试");
    }
}

void consumer_window::on_loop_event(double Money, double RoomTemp)
{
    // 更新状态
    if (RoomTemp >= 0 && Money >= 0)
    {
        ui->lcdNumber_2->display(QString::number(RoomTemp, 'f',2));
        ui->currentFee->setText(QString::number(Money, 'f',2));
    }
}

void consumer_window::on_state_change(int State)
{
    // 状态改变
    switch(State)
    {
    case STATE_RUNNING:
//        ui->currentState->setText("服务中");
        break;
    case STATE_PREEMPTED:
//        ui->currentState->setText("等待中");
        break;
    case STATE_DONE:
//        ui->currentState->setText("服务完成");
        break;
    default:
//        ui->currentState->setText("服务中");
        break;
    }
}

void consumer_window::on_rewarm(int isRewarm, double RoomTemp)
{
    // 回温
    if (isRewarm == 1)
    {
//        ui->currentState->setText("回温中");
        ui->lcdNumber_2->display(QString::number(RoomTemp, 'f',2));
    }
    else
    {
//        ui->currentState->setText("回温结束");
        ui->lcdNumber_2->display(QString::number(RoomTemp, 'f',2));
    }
}

void consumer_window::on_tempUp_clicked()
{
    uiTargetTemp = uiTargetTemp + 1;
    ui->lcdNumber->display(uiTargetTemp);
}

void consumer_window::on_tempDown_clicked()
{
    uiTargetTemp = uiTargetTemp - 1;
    ui->lcdNumber->display(uiTargetTemp);
}

void consumer_window::on_windUp_clicked()
{
    // 按下“增加风速”按钮
    // 风速变化：低 -> 中 -> 高 -> 低 循环
    uiFanSpeed = uiFanSpeed % 3 + 1;
    ui->currentSpeedofwind->setText(getWindStr(uiFanSpeed));
}

void consumer_window::on_windDown_clicked()
{
    // 按下“减少风速”按钮
    // 风速变化：高 -> 中 -> 低 -> 高 循环
    uiFanSpeed = (uiFanSpeed + 1) % 3 + 1;
    ui->currentSpeedofwind->setText(getWindStr(uiFanSpeed));
}

void consumer_window::on_open_clicked()
{
    emit signal_PowerOn();
}

void consumer_window::on_close_clicked()
{
    emit signal_PowerOff();
}
void consumer_window::closeEvent(QCloseEvent *event)
{
    emit signal_windowClose();
}

void consumer_window::on_temp_confirm_clicked()
{
    // 确认修改温度
    emit signal_ChangeTargetTemp(uiTargetTemp);
}

void consumer_window::on_wind_confirm_clicked()
{
    // 确认修改风速
    emit signal_ChangeFanSpeed(uiFanSpeed);
}
