#ifndef UTILS_H
#define UTILS_H


#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <header.h>

/**
 * 版本号:
 * @version v1.9
 *
 * 模块功能:
 * 提供通用功能函数
 *
 * Created on 2021/6/5.
 * @author mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/6/6.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 */

QString getWindStr(int FanSpeed);
QString getModeStr(int Mode);
QString getStateStr(int State);
QJsonObject String2Json(const QString& str);
QString Json2String(const QJsonObject& json);

#endif // UTILS_H
