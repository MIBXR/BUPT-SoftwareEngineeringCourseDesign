#ifndef CONSUMER_CONTROLLER_H
#define CONSUMER_CONTROLLER_H

#include <QUrl>
#include <QWidget>
#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <clientthread.h>
#include <consumer_window.h>
#include <header.h>

/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * consumer_controller
 *
 * 模块功能:
 * 用于接收用户请求控制器类
 *
 * Created on 2021/6/5.
 * @author mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/6/6.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/6/13.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 */

QT_BEGIN_NAMESPACE
namespace Ui
{
class consumer_controller;
}
QT_END_NAMESPACE

class consumer_controller : public QWidget
{
    Q_OBJECT

public:
    consumer_controller(QWidget* parent = nullptr);
    ~consumer_controller();

private:
    Ui::consumer_controller* ui;  // UI界面
    clientthread* connect_thread;   // 通信实体
    consumer_window* consumerWindow;  // 界面实体

    int rewarm_type = REWARM_TYPE_DONE;  // 回温场景：达到目的温度/关机
    qint64 timeOutCount;    //定时器超时次数
    double tempBeforeRewarm;    // 回温前温度
    double tempOriginal;    //  房间初始温度
    QTimer *mainTimer;  //全局定时器

    int RoomId;   // 房间号
    QString UserId;   // 用户号

    int maxTemp = MAX_TEMP_COLD;   // 最大温度
    int minTemp = MIN_TEMP_COLD;   // 最小温度

    int mMode;   // 当前模式
    double mCurrentTemp; // 当前温度
    int mTargetTemp;   // 设定温度
    int mFanSpeed;   // 设定风速

    int mModeReq;    // 当前待发送模式
    int mTargetTempReq;    // 待发送温度（显示温度）
    int mFanSpeedReq;    // 待发送风速（显示风速）


    double mCurrentFee = 0.00;   // 当前费用
    double mTotalFee = 0.00;   // 全部费用
    double mRateFee = 0.00;   // 费率

    bool isOn = false;  // 是否开机
    int mACState;  // 开机后才有空调状态：运行，抢占，完成


    void send_state_after_schedual(int State);    // 由于调度策略发生状态变化后回送信息
    void start_rewarm(int type);    // 回温

signals:
    void signal_PowerOn(int Mode, double CurrentTemp, int TargetTemp, int FanSpeed, double CurrentFee, double TotalFee, double RateFee);  // 开机
    void signal_RequestState(double CurrentTemp, double CurrentFee, double TotalFee); // 请求状态
    void signal_ChangeTargetTemp(int TargetTemp); // 更改目标温度
    void signal_ChangeFanSpeed(double RateFee);   // 更改风速
    void signal_RequestRelease(int state);   // 达到目标温度
    void signal_RequestTempUp(double CurrentTemp);    // 回温
    void signal_PowerOff(double isOK); // 关机

    void signal_loggined(double CurrentTemp, int RoomId); // 连接成功
    void signal_loop_event(double Money, double RoomTemp);  // 定时修改金额和室温
    void signal_state_change(int State);  //  被调度产生的状态变化
    void signal_rewarm(int isRewarm, double RoomTemp);  // 回温

private slots:
    void on_PowerOn();  // 开机
    void on_RequestState(); // 请求状态（可能改为由服务器发）
    void on_ChangeTargetTemp(int TargetTemp); // 更改目标温度
    void on_ChangeFanSpeed(int FanSpeed);   // 更改风速
    void on_RequestRelease();   // 达到目标温度
    void on_RequestTempUp();    // 回温
    void on_PowerOff(); // 关机

    void messageFromServer(QString message);    // 服务器传来消息
    void on_btnOpen_clicked();  // open键点击
    void onTimeout();   // 定时器超时处理
    void subWindowClosed(); // 子界面关闭
};
#endif // CONSUMER_CONTROLLER_H
