#include "consumer_controller.h"
#include "ui_consumer_controller.h"


consumer_controller::consumer_controller(QWidget* parent)
    : QWidget(parent)
    , ui(new Ui::consumer_controller)
{
    ui->setupUi(this);
    setWindowTitle(tr("用户登录"));

    //新建数据传输对象与操作界面对象
    connect_thread = new clientthread();
    consumerWindow = new consumer_window();

    //创建定时器
    timeOutCount = 0;
    mainTimer = new QTimer(this);
    connect(mainTimer, SIGNAL(timeout()), this, SLOT(onTimeout()));

    //绑定弹出窗口与隐藏窗口的信号
    connect(this, &consumer_controller::signal_loggined, consumerWindow, &consumer_window::onLoggined);
    connect(consumerWindow, &consumer_window::signal_windowClose, this, &consumer_controller::subWindowClosed);

    //连接结果确认
    connect(connect_thread, &clientthread::sgn_connected, this, [=]() {
        ui->btnOpen->setText("Close");
        ui->footLabel->setText(QString("Address:%1  Port:%2")
                                   .arg(connect_thread->getAddress())
                                   .arg(connect_thread->getPort()));
        emit signal_loggined(mCurrentTemp, RoomId);

        QJsonObject jsonMessage;    //要发送的完整消息
        jsonMessage.insert("MsgType", MSG_TYPE_ENTERROOM);
        jsonMessage.insert("RoomId", QString::number(RoomId,10));
        QString strJson = Json2String(jsonMessage);
        qDebug() << "send: " << strJson;
        connect_thread->sendMessage(strJson);

        qDebug() << "Client connected";
        this->hide();
    });
    connect(connect_thread, &clientthread::sgn_disconnected, this, [=]() {
        ui->btnOpen->setText("Open");
        qDebug() << "Client disconnected";
    });

    // 应用逻辑层到控制器层的消息（接收来自服务器的数据并处理）
    connect(connect_thread, &clientthread::sgn_recvMessage, this, &consumer_controller::messageFromServer);

    // UI层到控制器层的消息
    connect(consumerWindow, &consumer_window::signal_PowerOn, this, &consumer_controller::on_PowerOn);
    connect(consumerWindow, &consumer_window::signal_RequestState, this, &consumer_controller::on_RequestState);
    connect(consumerWindow, &consumer_window::signal_ChangeTargetTemp, this, &consumer_controller::on_ChangeTargetTemp);
    connect(consumerWindow, &consumer_window::signal_ChangeFanSpeed, this, &consumer_controller::on_ChangeFanSpeed);
    connect(consumerWindow, &consumer_window::signal_RequestRelease, this, &consumer_controller::on_RequestRelease);
    connect(consumerWindow, &consumer_window::signal_RequestTempUp, this, &consumer_controller::on_RequestTempUp);
    connect(consumerWindow, &consumer_window::signal_PowerOff, this, &consumer_controller::on_PowerOff);

    // 控制器层到UI层的消息
    connect(this, &consumer_controller::signal_PowerOn, consumerWindow, &consumer_window::on_PowerOn);
    connect(this, &consumer_controller::signal_RequestState, consumerWindow, &consumer_window::on_RequestState);
    connect(this, &consumer_controller::signal_ChangeTargetTemp, consumerWindow, &consumer_window::on_ChangeTargetTemp);
    connect(this, &consumer_controller::signal_ChangeFanSpeed, consumerWindow, &consumer_window::on_ChangeFanSpeed);
    connect(this, &consumer_controller::signal_RequestRelease, consumerWindow, &consumer_window::on_RequestRelease);
    connect(this, &consumer_controller::signal_RequestTempUp, consumerWindow, &consumer_window::on_RequestTempUp);
    connect(this, &consumer_controller::signal_PowerOff, consumerWindow, &consumer_window::on_PowerOff);
    connect(this, &consumer_controller::signal_loop_event, consumerWindow, &consumer_window::on_loop_event);
    connect(this, &consumer_controller::signal_state_change, consumerWindow, &consumer_window::on_state_change);
    connect(this, &consumer_controller::signal_rewarm, consumerWindow, &consumer_window::on_rewarm);
}

consumer_controller::~consumer_controller()
{
    connect_thread->closeClient();
    if(mainTimer->isActive())
        mainTimer->stop();  //关闭定时器
    delete ui;
}

void consumer_controller::on_PowerOn()
{
    // 开机操作

    if(mainTimer->isActive())
        mainTimer->stop();  //关闭定时器

    // 组包并发送
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType", MSG_TYPE_TURNON);
    jsonMessage.insert("RoomId", QString::number(RoomId, 10));
    jsonMessage.insert("UserId", UserId);
    jsonMessage.insert("RoomTemp", QString::number(mCurrentTemp, 'f', 2));
    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
    connect_thread->sendMessage(strJson);
}

void consumer_controller::on_RequestState()
{
    // 由服务器主动发送
}

void consumer_controller::on_ChangeTargetTemp(int TargetTemp)
{
    // 调温操作
    if (TargetTemp >= minTemp && TargetTemp <= maxTemp)
    {
        mTargetTempReq = TargetTemp;
        QJsonObject jsonMessage;
        jsonMessage.insert("MsgType", MSG_TYPE_CHANGETEMP);
        jsonMessage.insert("RoomId", QString::number(RoomId, 10));
        jsonMessage.insert("UserId", UserId);
        jsonMessage.insert("TargetTemp", QString::number(mTargetTempReq, 10));
        QString strJson = Json2String(jsonMessage);
        qDebug() << "send: " << strJson;
        connect_thread->sendMessage(strJson);
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "温度超出调节范围");
        return;
    }
}

void consumer_controller::on_ChangeFanSpeed(int FanSpeed)
{
    // 调风操作
    if (FanSpeed >= FANSPEED_LOWWIND && FanSpeed <= FANSPEED_HIGHWIND)
    {
        mFanSpeedReq = FanSpeed;
        QJsonObject jsonMessage;
        jsonMessage.insert("MsgType", MSG_TYPE_CHANGEWIND);
        jsonMessage.insert("RoomId", QString::number(RoomId, 10));
        jsonMessage.insert("UserId", UserId);
        jsonMessage.insert("WindSpeed", QString::number(mFanSpeedReq , 10));
        QString strJson = Json2String(jsonMessage);
        qDebug() << "send: " << strJson;
        connect_thread->sendMessage(strJson);
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "风速超出调节范围");
        return;
    }
}

void consumer_controller::on_RequestRelease()
{
    // 由服务器主动发送
}

void consumer_controller::on_RequestTempUp()
{
    // 由客户端模拟
}

void consumer_controller::on_PowerOff()
{
    // 关机操作
    if (isOn)
    {
        QJsonObject jsonMessage;
        jsonMessage.insert("MsgType", MSG_TYPE_TURNOFF);
        jsonMessage.insert("RoomId", QString::number(RoomId, 10));
        jsonMessage.insert("UserId", UserId);
        QString strJson = Json2String(jsonMessage);
        qDebug() << "send: " << strJson;
        connect_thread->sendMessage(strJson);
        start_rewarm(REWARM_TYPE_OFF);
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "关机状态下不能关机");
    }
}

void consumer_controller::messageFromServer(QString message)
{
    // 服务器消息处理
    qDebug() << "rec:" << message;
    QJsonObject jsonMessage = String2Json(message);
    if (jsonMessage.contains("MsgType"))
    {
        QJsonValue value = jsonMessage.value("MsgType");    //获取指定key对应的value
        QJsonValue inf;
        int msgType = value.toInt();

        switch (msgType)
        {
        case MSG_TYPE_TURNON:  // 开机结果分析
            // 判断消息包内容是否完整
            if (jsonMessage.contains("Mode") && jsonMessage.contains("WindSpeed") && jsonMessage.contains("TargetTemp") && jsonMessage.contains("FeeRate"))
            {
                isOn = true;
                inf = jsonMessage.value("Mode");
                mMode = inf.toString().toInt();
                inf = jsonMessage.value("WindSpeed");
                mFanSpeed = inf.toString().toInt();
                inf = jsonMessage.value("TargetTemp");
                mTargetTemp = inf.toString().toInt();
                inf = jsonMessage.value("FeeRate");
                mRateFee = inf.toString().toDouble();

                // 设定温度调节区间
                if (mMode == MODE_COOL)
                {
                    minTemp = MIN_TEMP_COLD;
                    maxTemp = MAX_TEMP_COLD;
                }
                else
                {
                    minTemp = MIN_TEMP_WARM;
                    maxTemp = MAX_TEMP_WARM;
                }

                // 通知UI层更新界面
                emit signal_PowerOn(mMode, mCurrentTemp, mTargetTemp, mFanSpeed, mCurrentFee, mTotalFee, mRateFee);
            }
            else
            {
                // 异常处理
                emit signal_PowerOn(-1, -1, -1, -1, -1, -1, -1);
                qDebug() << "Server json error: do not have all required field(s)";
            }
            break;
        case MSG_TYPE_ENTERROOM:  // 进入房间结果分析
            // 判断消息包内容是否完整
            if (jsonMessage.contains("UserId"))
            {
                inf = jsonMessage.value("UserId");
                if (inf != "-1")
                {
                    UserId = inf.toString();
                }
            }
            if (jsonMessage.contains("RoomId"))
            {
                inf = jsonMessage.value("RoomId");
                if (inf != "-1")
                {
                    RoomId = inf.toString().toInt();
                }
            }
            break;
        case MSG_TYPE_CHANGEWIND:  // 调风结果分析
            // 判断消息包内容是否完整
            if (jsonMessage.contains("FeeRate"))
            {
                inf = jsonMessage.value("FeeRate");
                double tmp = inf.toString().toDouble();
                if (tmp > 0)
                {
                    mRateFee = tmp;
                    // 通知UI层更新界面
                    emit signal_ChangeFanSpeed(mRateFee);
                }
                else
                {
                    // 异常处理
                    emit signal_ChangeFanSpeed(-1);
                    qDebug() << "Server change error: do not return correct FeeRate";
                }
            }
            else
            {
                // 异常处理
                emit signal_ChangeFanSpeed(-1);
                qDebug() << "Server json error: do not have all required field(s)";
            }
            break;
        case MSG_TYPE_CHANGETEMP:  // 调温结果分析
            // 判断消息包内容是否完整
            if (jsonMessage.contains("Ack"))
            {
                inf = jsonMessage.value("Ack").toString().toInt();
                if (inf == 1)
                {
                    mTargetTemp = mTargetTempReq;
                    // 通知UI层更新界面
                    emit signal_ChangeTargetTemp(mTargetTemp);
                }
                else
                {
                    mTargetTempReq = mTargetTemp;
                    emit signal_ChangeTargetTemp(-1);
                    qDebug() << "Server change error: do not ack";
                }
            }
            else
            {
                // 异常处理
                emit signal_ChangeTargetTemp(-1);
                qDebug() << "Server json error: do not have all required field(s)";
            }
            break;
        case MSG_TYPE_TURNOFF:  // 关机结果分析
            // 判断消息包内容是否完整
            if (jsonMessage.contains("Money"))
            {
                isOn = false;
                inf = jsonMessage.value("Money");
                mTotalFee = mTotalFee + inf.toString().toDouble();
                // 通知UI层更新界面
                emit signal_PowerOff(mTotalFee);
            }
            else
            {
                // 异常处理
                emit signal_PowerOff(-1);
            }
            break;
        case MSG_TYPE_SHOWCURRENTMONEY:  // 请求状态结果分析
            // 判断消息包内容是否完整
            if (jsonMessage.contains("Money") && jsonMessage.contains("RoomTemp"))
            {
                mCurrentTemp = jsonMessage.value("RoomTemp").toString().toDouble();
                mCurrentFee = jsonMessage.value("Money").toString().toDouble();

                // 通知UI层更新界面
                emit signal_loop_event(mCurrentFee, mCurrentTemp);
            }
            else
            {
                // 异常处理
                emit signal_loop_event(-1, -1);
            }
            break;
        case STATE_RUNNING:  // 可以运行（分配到服务对象）的通知
            mACState = STATE_RUNNING;
            send_state_after_schedual(mACState);
            emit signal_state_change(mACState);
            break;
        case STATE_PREEMPTED:  // 被抢占的通知
            mACState = STATE_PREEMPTED;
            send_state_after_schedual(mACState);
            emit signal_state_change(mACState);
            break;
        case STATE_DONE:  // 服务完成的通知
            mACState = STATE_DONE;
            send_state_after_schedual(mACState);
            start_rewarm(REWARM_TYPE_DONE);
            emit signal_state_change(mACState);
            break;
        default:
            qDebug() << "Server json error: do not have this msg type";
            break;
        }
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "服务器数据异常或网络异常！");
        return;
    }
}

void consumer_controller::send_state_after_schedual(int State)
{
    // 应答服务器的调度结果
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType", State);
    jsonMessage.insert("RoomId", QString::number(RoomId, 10));
    jsonMessage.insert("RoomTemp", QString::number(mCurrentTemp, 'f', 2));
    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
    connect_thread->sendMessage(strJson);
}

void consumer_controller::start_rewarm(int type)
{
    // 回温

    // 如果是达到目标温度的回温
    if (type == REWARM_TYPE_DONE)
    {
        rewarm_type = REWARM_TYPE_DONE;
        tempBeforeRewarm = mCurrentTemp;
        if(mainTimer->isActive())
            mainTimer->stop();
        mainTimer->start(REWARM_FREQ);
    }
    // 否则是关机回温
    else
    {
        rewarm_type = REWARM_TYPE_OFF;
        if(mainTimer->isActive())
            mainTimer->stop();
        mainTimer->start(REWARM_FREQ);
    }
}

void consumer_controller::onTimeout()
{
    // 如果是到达设定温度回温
    if (rewarm_type == REWARM_TYPE_DONE)
    {
        // 如果是制冷模式
        if (mMode == MODE_COOL)
        {
            // 如果还没回到比目标温度高一度的时候
            if (mCurrentTemp < mTargetTemp + REWARM_MAX)
            {
                mCurrentTemp = mCurrentTemp + REWARM_DELTA;
                QJsonObject jsonMessage;
                jsonMessage.insert("MsgType", MSG_TYPE_REWARM);
                jsonMessage.insert("RoomId", QString::number(RoomId, 10));
                jsonMessage.insert("RoomTemp", QString::number(mCurrentTemp, 'f', 2));
                QString strJson = Json2String(jsonMessage);
                qDebug() << "send: " << strJson;
                connect_thread->sendMessage(strJson);
                emit signal_rewarm(1, mCurrentTemp);
                if (mCurrentTemp < mTargetTemp + REWARM_MAX)
                {
                    return;
                }
                // 如果这次回温后，比目标温度高一度，就停止回温，请求重新服务
                else
                {
                    emit signal_rewarm(-1, mCurrentTemp);
                    if(mainTimer->isActive())
                        mainTimer->stop();
                    on_PowerOn();
                }
            }
            else
            {
                emit signal_rewarm(-1, mCurrentTemp);
                if(mainTimer->isActive())
                    mainTimer->stop();
                on_PowerOn();
            }
        }
        // 如果是制热模式
        else
        {
            if (mCurrentTemp > mTargetTemp - REWARM_MAX)
            {
                mCurrentTemp = mCurrentTemp - REWARM_DELTA;
                QJsonObject jsonMessage;
                jsonMessage.insert("MsgType", MSG_TYPE_REWARM);
                jsonMessage.insert("RoomId", QString::number(RoomId, 10));
                jsonMessage.insert("RoomTemp", QString::number(mCurrentTemp, 'f', 2));
                QString strJson = Json2String(jsonMessage);
                qDebug() << "send: " << strJson;
                connect_thread->sendMessage(strJson);
                emit signal_rewarm(1, mCurrentTemp);
                if (mCurrentTemp > mTargetTemp - REWARM_MAX)
                {
                    return;
                }
                else
                {
                    emit signal_rewarm(-1, mCurrentTemp);
                    if(mainTimer->isActive())
                        mainTimer->stop();
                    on_PowerOn();
                }
            }
            else
            {
                emit signal_rewarm(-1, mCurrentTemp);
                if(mainTimer->isActive())
                    mainTimer->stop();
                on_PowerOn();
            }
        }
    }
    // 如果是关机回温
    else
    {
        qDebug() << "rewarm:" << mCurrentTemp << ","<< tempOriginal;
        if (mMode == MODE_COOL)
        {
            if (mCurrentTemp < tempOriginal - VERY_SIMILAR)
            {
                mCurrentTemp = mCurrentTemp + REWARM_DELTA;
                emit signal_rewarm(1, mCurrentTemp);
            }
            else
            {
                emit signal_rewarm(-1, mCurrentTemp);
                if(mainTimer->isActive())
                    mainTimer->stop();
            }
        }
        else
        {
            if (mCurrentTemp > tempOriginal + VERY_SIMILAR)
            {
                mCurrentTemp = mCurrentTemp - REWARM_DELTA;
                emit signal_rewarm(1, mCurrentTemp);
            }
            else
            {
                emit signal_rewarm(-1, mCurrentTemp);
                if(mainTimer->isActive())
                    mainTimer->stop();
            }
        }
    }
}

void consumer_controller::on_btnOpen_clicked()
{
    if (ui->btnOpen->text() == "Open")  //进入房间
    {
        connect_thread->openClient(QUrl(ui->editUrl->text()));
        RoomId = ui->lineEdit->text().toInt();
        mCurrentTemp = ui->currentTemp->text().toDouble();
        tempOriginal = mCurrentTemp;
    }
    else
    {
        connect_thread->closeClient();
        consumerWindow->close();
    }
}

void consumer_controller::subWindowClosed()
{
    connect_thread->closeClient();
    ui->btnOpen->setText("Open");
    ui->footLabel->setText("未连接");
    isOn = false;
    if (mainTimer->isActive())
    {
        mainTimer->stop();
    }
    this->show();
}
