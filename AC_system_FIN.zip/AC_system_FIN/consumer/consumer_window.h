#ifndef CONSUMER_WINDOW_H
#define CONSUMER_WINDOW_H

#include <QWidget>
#include <QDebug>
#include <QCloseEvent>
#include <QMessageBox>
#include <header.h>
#include <utils.h>

/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * consumer_window
 *
 * 模块功能:
 * 住户的用户界面，UI层
 *
 * Created on 2021/6/5.
 * @author mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/6/6.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/6/13.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 */

namespace Ui {
class consumer_window;
}

class consumer_window : public QWidget
{
    Q_OBJECT

public:
    consumer_window(QWidget *parent = nullptr);
    ~consumer_window();

private:
    Ui::consumer_window *ui;
    int uiTargetTemp;   // 显示设定温度
    int uiFanSpeed = FANSPEED_MIDDLEWIND;   // 显示设定风速
    int uiFanSpeedReq;   // 还未得到确认的显示设定风速

signals:
    void signal_PowerOn();  // 开机
    void signal_RequestState(); // 请求状态（改为由服务器发）
    void signal_ChangeTargetTemp(int TargetTemp); // 更改目标温度
    void signal_ChangeFanSpeed(int FanSpeed);   // 更改风速
    void signal_RequestRelease();   // 达到目标温度
    void signal_RequestTempUp();    // 回温
    void signal_PowerOff(); // 关机

    void signal_windowClose();  // 子界面关闭

private slots:
    // 各按钮点击事件
    void on_tempUp_clicked();
    void on_tempDown_clicked();
    void on_windUp_clicked();
    void on_windDown_clicked();
    void on_open_clicked();
    void on_close_clicked();
    void on_temp_confirm_clicked();
    void on_wind_confirm_clicked();

public slots:
    void on_PowerOn(int Mode, double CurrentTemp, int TargetTemp, int FanSpeed, double CurrentFee, double TotalFee, double RateFee);  // 开机
    void on_RequestState(double CurrentTemp, double CurrentFee, double TotalFee); // 请求状态
    void on_ChangeTargetTemp(int TargetTemp); // 更改目标温度
    void on_ChangeFanSpeed(double RateFee);   // 更改风速
    void on_RequestRelease(int state);   // 达到目标温度
    void on_RequestTempUp(double CurrentTemp);    // 回温
    void on_PowerOff(double isOK); // 关机
    void on_loop_event(double Money, double RoomTemp);  // 定时修改金额和室温
    void on_state_change(int State);  //  被调度产生的状态变化
    void on_rewarm(int isRewarm, double RoomTemp);  // 回温

    void onLoggined(double CurrentTemp, int RoomId);  // 窗口打开事件（原来是登陆成功事件，现在不登录了，就转为单纯的窗口打开事件）

protected:
    void closeEvent(QCloseEvent *event);    // 窗口关闭事件
};
#endif // CONSUMER_WINDOW_H
