#ifndef clientthread_H
#define clientthread_H
#include <QDebug>
#include <QObject>
#include <QThread>
#include <QTime>
#include <QWidget>
#include <QtWebSockets>
#include <winsock2.h>

/**
 * 版本号:
 * @version v1.0
 *
 * 类名:
 * clientthread
 *
 * 模块功能:
 * 用于通信的系统管理类
 *
 * Created on 2021/5/1.
 * @author mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/5/5.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 */

class clientthread : public QObject
{
    Q_OBJECT
public:
    clientthread();
    ~clientthread();

public:
    void openClient(QUrl url);  // 建立连接
    void closeClient();  // 关闭连接
    void sendMessage(QString text); // 发送字符串消息
    QString getAddress();  // 获取IP地址
    QString getPort();  // 获取端口号

private:
    QString thread_msg;
    QWebSocket* client;

signals:
    void sgn_connected();
    void sgn_disconnected();
    void sgn_recvMessage(QString msg);
};

#endif // clientthread_H
