#ifndef HEADER_H
#define HEADER_H

// 消息类型宏定义
#define MSG_TYPE_TURNON 0
#define MSG_TYPE_ENTERROOM 1
#define MSG_TYPE_CHANGEWIND 2
#define MSG_TYPE_CHANGETEMP 3
#define MSG_TYPE_CHANGEMODE 4   // 按照新需求，此命令没用
#define MSG_TYPE_SHOWCURRENTMONEY 5
#define MSG_TYPE_TURNOFF 13
#define MSG_TYPE_REWARM 14

// 风速宏定义
#define FANSPEED_LOWWIND 1
#define FANSPEED_MIDDLEWIND 2
#define FANSPEED_HIGHWIND 3

// 模式宏定义
#define MODE_COOL 1
#define MODE_WARM 2
#define MODE_OFF 3  // 按照新需求，此命令没用

// 客户空调状态宏定义
#define STATE_RUNNING 100
#define STATE_PREEMPTED 101
#define STATE_DONE 102

#define MAX_TEMP_COLD 27
#define MIN_TEMP_COLD 16
#define MAX_TEMP_WARM 28
#define MIN_TEMP_WARM 22

// 回温场景
#define REWARM_DELTA 0.05
#define REWARM_FREQ 6000
#define REWARM_MAX 0.999999
#define VERY_SIMILAR 0.01

#define REWARM_TYPE_DONE 1
#define REWARM_TYPE_OFF 2

#endif // HEADER_H
