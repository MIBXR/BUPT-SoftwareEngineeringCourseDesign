#include "reception_controller.h"
#include "ui_reception_controller.h"

reception_controller::reception_controller(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::reception_controller)
{
    ui->setupUi(this);

    setWindowTitle(tr("loading..."));

    // 新建数据传输对象与操作界面对象
    connect_thread = new clientthread();
    receptionWindow = new reception_window();
    rdWindow = new RD();
    invoiceWindow = new Invoice();
    connect(receptionWindow, &reception_window::signal_windowClose, this, &reception_controller::subWindowClosed);

    // Socket连接状态
    connect(connect_thread, &clientthread::sgn_connected, this, [=]() {
        receptionWindow->show();
        qDebug() << "Client connected";
        this->hide();
    });
    connect(connect_thread, &clientthread::sgn_disconnected, this, [=]() {
        qDebug() << "Client disconnected";
        this->show();
    });

    // 应用逻辑层到控制器层的消息（接受来自服务器的消息并处理）
    connect(connect_thread, &clientthread::sgn_recvMessage, this, &reception_controller::messageFromServer);

    // UI层到控制器层的消息
    connect(receptionWindow, &reception_window::signal_CreateRD, this, &reception_controller::on_CreateRD);
    connect(receptionWindow, &reception_window::signal_CreateInvoice, this, &reception_controller::on_CreateInvoice);
    connect(receptionWindow, &reception_window::signal_PrintRD, this, &reception_controller::on_PrintRD);
    connect(receptionWindow, &reception_window::signal_PrintInvoice, this, &reception_controller::on_PrintInvoice);
    // 控制器层到UI层的消息
    connect(this, &reception_controller::signal_CreateRD, receptionWindow, &reception_window::on_CreatRD);
    connect(this, &reception_controller::signal_CreateInvoice, receptionWindow, &reception_window::on_CreatInvoice);

    // 控制器层到详单对象
    connect(this, &reception_controller::signal_CreateRD,rdWindow,&RD::on_CreateRD);
    connect(this, &reception_controller::signal_clearRD, rdWindow, &RD::on_clearRD); // 创建新详单之前清除旧详单
    connect(this, &reception_controller::signal_PrintRD,rdWindow,&RD::on_PrintRD);

    // 控制器层到账单对象
    connect(this, &reception_controller::signal_CreateInvoice,invoiceWindow,&Invoice::on_CreateInvoice);
    connect(this, &reception_controller::signal_PrintInvoice,invoiceWindow,&Invoice::on_PrintInvoice);
}

reception_controller::~reception_controller()
{
    delete ui;
}

void reception_controller::on_CreateRD(int RoomId)
{
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType", MSG_TYPE_CREATERD);
    jsonMessage.insert("RoomId", QString::number(RoomId, 10));
    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
    connect_thread->sendMessage(strJson);

}
void reception_controller::on_CreateInvoice(int RoomId){
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType", MSG_TYPE_CREATEIN);
    jsonMessage.insert("RoomId", QString::number(RoomId, 10));
    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
    connect_thread->sendMessage(strJson);
}


void reception_controller::on_btnOpen_clicked()
{
    connect_thread->openClient(QUrl(ui->editUrl->text()));
}

void reception_controller::subWindowClosed()
{
    connect_thread->closeClient();
    this->show();
}

void reception_controller::messageFromServer(QString message){
    qDebug() << "rec:" << message;
    QJsonObject jsonMessage = String2Json(message);
    if (jsonMessage.contains("MsgType")){
        qDebug()<<"OK";
        QJsonValue value = jsonMessage.value("MsgType");    // 获取指定key对应的value
        QJsonValue inf;
        int msgType = value.toInt();
        qDebug() << "msgType:"<<msgType;
        switch (msgType) {
        case MSG_TYPE_CREATERD:  // 接收创建详单的消息
            {
            emit signal_clearRD();
            QJsonValue id = jsonMessage.value("RoomId");
            mRoomId = id.toInt();
            qDebug() <<"RoomId"<< mRoomId;
            if (jsonMessage.contains("Detail"))
            {
                QJsonObject allDetailItems = jsonMessage.value("Detail").toObject();
                int i = 1;
                while (allDetailItems.contains(QString::number(i, 10)))
                {
                    QJsonObject DetailItem = allDetailItems.value(QString::number(i, 10)).toObject();

                    mRequestStartTime = DetailItem.value("RequestStartTime").toString().toInt();
                    mRequestEndTime = DetailItem.value("RequestEndTime").toString().toInt();
                    mPartFee =DetailItem.value("PartFee").toString().toDouble();
                    mWindSpeed = DetailItem.value("WindSpeed").toString().toInt();
                    mFeeRate =DetailItem.value("FeeRate").toString().toDouble();

                    qDebug() <<"StartTime"<<  mRequestStartTime;
                    qDebug() <<  mRequestEndTime;
                    qDebug() <<  mPartFee;
                    qDebug() <<  mWindSpeed;
                    qDebug() <<  mFeeRate;

                    emit signal_CreateRD(mRoomId, mRequestStartTime, mRequestEndTime,mPartFee, mWindSpeed, mFeeRate);

                    i++;
                }


            }
        }break;
        case MSG_TYPE_CREATEIN:
        {
            mRoomId = jsonMessage.value("RoomId").toString().toInt();
            qDebug() << "RoomId"<< mRoomId;
            mMoney = jsonMessage.value("Money").toString().toDouble();
            qDebug() << "Money" << mMoney;
            mInTime = jsonMessage.value("InTime").toString().toInt();
            mOutTime = jsonMessage.value("OutTime").toString().toInt();
            emit signal_CreateInvoice(mRoomId,mMoney, mInTime, mOutTime);

        }break;

        }
    }

}


void reception_controller::on_PrintRD(int RoomId){
    emit signal_PrintRD();
}
void reception_controller::on_PrintInvoice(int RoomId){
    emit signal_PrintInvoice();
}
