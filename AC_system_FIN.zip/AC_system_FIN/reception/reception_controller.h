/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * reception_controller
 *
 * 模块功能:
 * 用于接收前台请求的控制器类
 *
 * Created on 2021/6/5.
 * @author 15303713488@163.com (Zhao Zhao)
 *
 * Edited on 2021/6/15.
 * @editer 15303713488@163.com (Zhao Zhao)
 *
 */
#ifndef RECEPTION_CONTROLLER_H
#define RECEPTION_CONTROLLER_H
#include "reception_window.h"
#include "rd.h"
#include "invoice.h"
#include <QUrl>
#include <QWidget>
#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <clientthread.h>
#include <reception_window.h>
#include <header.h>

QT_BEGIN_NAMESPACE
namespace Ui { class reception_controller; }
QT_END_NAMESPACE

class reception_controller : public QWidget
{
    Q_OBJECT

public:
    reception_controller(QWidget *parent = nullptr);
    ~reception_controller();

private:
    Ui::reception_controller *ui;
    clientthread* connect_thread;   // 通信实体
    reception_window* receptionWindow;  // 界面实体
    RD* rdWindow; // 详单实体
    Invoice* invoiceWindow;  // 账单实体
    int mRoomId;
    int mRequestStartTime;
    int mRequestEndTime;
    double mPartFee;
    int mWindSpeed;
    double mFeeRate;
    double mMoney;
    int mInTime;
    int mOutTime;
signals:
    // 这里填控制器层到UI层的信号：
    void signal_CreateRD(int mRoomId, int mRequestStartTime, int mRequestEndTime, double mPartFee, int mWindSpeed, double mFeeRate);
    void signal_CreateInvoice(int mRoomId, double mMoney, int mTimeIn, int mTimeOut);


    // 控制器层到详单对象的信号
    void signal_PrintRD();
    void signal_clearRD();

    // 控制器层到帐单的信号
    void signal_PrintInvoice();

private slots:
    // 这里填UI层到控制器层的消息对应的槽函数，这里以前台为例：
    void on_CreateRD(int RoomId);
    void on_CreateInvoice(int RoomId);
    void on_PrintRD(int RoomId);
    void on_PrintInvoice(int RoomId);

    // 这里是QT自动生成的槽函数
    void on_btnOpen_clicked();

    // 这里是其他槽函数
    void messageFromServer(QString message);    // 服务器传来消息
    void subWindowClosed(); // 子界面关闭
};
#endif // RECEPTION_CONTROLLER_H
