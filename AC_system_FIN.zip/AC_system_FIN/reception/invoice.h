/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * Invoice
 *
 * 模块功能:
 * 用于接受控制器与账单相关请求的账单类
 *
 * Created on 2021/6/5.
 * @author 15303713488@163.com (Zhao Zhao)
 *
 * Edited on 2021/6/15.
 * @editer 15303713488@163.com (Zhao Zhao)
 *
 */
#ifndef INVOICE_H
#define INVOICE_H

#include <QObject>
#include <QObject>
#include <QUrl>
#include <QWidget>
#include <QObject>
#include <QDebug>
#include <header.h>
#include <QFile>
#include <qdatetime.h>


class Invoice : public QObject
{
    Q_OBJECT
public:
    explicit Invoice(QObject *parent = nullptr);
    int RoomId;
    double Money;
    int InTime;
    int OutTime;

signals:

public slots:
    // 槽函数：接收从控制器发来的信号
    void on_CreateInvoice(int mRoomId, double mMoney, int mTimeIn, int mTimeOut);
    void on_PrintInvoice();
};

#endif
