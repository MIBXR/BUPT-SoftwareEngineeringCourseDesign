/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * RD
 *
 * 模块功能:
 * 用于接受控制器与详单相关请求的详单类
 *
 * Created on 2021/6/5.
 * @author 15303713488@163.com (Zhao Zhao)
 *
 * Edited on 2021/6/15.
 * @editer 15303713488@163.com (Zhao Zhao)
 *
 */
#ifndef RD_H
#define RD_H

#include <QObject>
#include <QUrl>
#include <QWidget>
#include <QObject>
#include <QDebug>
#include <header.h>
#include <QFile>
#include <qdatetime.h>
class RD : public QObject
{
    Q_OBJECT
public:
    RD(QObject *parent = nullptr);
    ~RD();
    QList<QString> Rd_List;  // 详单列表


signals:

public slots:
    // 控制器层到详单对象的槽函数
   void on_CreateRD(int mRoomId, int mRequestStartTime, int mRequestEndTime, double mPartFee, int mWindSpeed, double mFeeRate);
   void on_clearRD();
   void on_PrintRD();

};

#endif // RD_H
