/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * reception_window
 *
 * 模块功能:
 * 用于发送前台请求的UI界面类
 *
 * Created on 2021/6/5.
 * @author 15303713488@163.com (Zhao Zhao)
 *
 * Edited on 2021/6/15.
 * @editer 15303713488@163.com (Zhao Zhao)
 *
 */
#ifndef RECEPTION_WINDOW_H
#define RECEPTION_WINDOW_H

#include <QWidget>
#include <QDebug>
#include <QCloseEvent>
#include <QMessageBox>
#include <header.h>
#include <utils.h>
#include <qdatetime.h>

namespace Ui {
class reception_window;
}

class reception_window : public QWidget
{
    Q_OBJECT

public:

    explicit reception_window(QWidget *parent = nullptr);
    ~reception_window();

private:
    Ui::reception_window *ui;

signals:
    // UI层到控制器层的信号：
    void signal_CreateRD(int RoomId);  // 创建详单
    void signal_CreateInvoice(int RoomId);  // 创建账单
    void signal_PrintRD(int RoomId);  // 打印详单
    void signal_PrintInvoice(int RoomId);  // 打印账单


    void signal_windowClose();

private slots:
    // 这里是UI按钮等控件的事件槽函数

    void on_RD_clicked();
    void on_eInvoice_clicked();
    void on_PrintRD_clicked();
    void on_PrintInvoice_clicked();
public slots:
    // 这里填控制器层到UI层的消息对应的槽函数：
    void on_CreatRD(int mRoomId, int mRequestStartTime, int mRequestEndTime, double mPartFee, int mWindSpeed, double mFeeRate);
    void on_CreatInvoice(int mRoomId, double mMoney, int mTimeIn, int mTimeOut);
protected:
    void closeEvent(QCloseEvent *event);    // 窗口关闭事件
};

#endif // RECEPTION_WINDOW_H
