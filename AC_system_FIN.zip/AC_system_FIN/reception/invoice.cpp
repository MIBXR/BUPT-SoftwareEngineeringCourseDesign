#include "invoice.h"

Invoice::Invoice(QObject *parent) : QObject(parent)
{

}

void Invoice::on_CreateInvoice(int mRoomId, double mMoney, int mTimeIn, int mTimeOut){
    // 对账单对象进行赋值
    RoomId = mRoomId;
    Money = mMoney;
    InTime = mTimeIn;
    OutTime = mTimeOut;
}


void Invoice::on_PrintInvoice(){
    QFile file("invoice.txt");  // 设置文件位置
    if (!file.open(QFile::WriteOnly | QFile::Text))
       {
           qDebug()<<"cannot open the file!";
       }
    QTextStream out(&file);
    QDateTime IN_timestamp,OUT_timestamp;
    IN_timestamp.setTime_t(InTime);
    OUT_timestamp.setTime_t(OutTime);
    out <<IN_timestamp.toString(Qt::SystemLocaleShortDate)<<"-"<<OUT_timestamp.toString(Qt::SystemLocaleShortDate)<< tr("\t ") << RoomId << tr("号房间共消费") << Money <<tr("元。");
}
