#include "reception_controller.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    reception_controller w;
    w.show();
    return a.exec();
}
