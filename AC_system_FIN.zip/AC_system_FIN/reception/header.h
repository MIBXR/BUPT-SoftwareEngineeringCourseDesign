#ifndef HEADER_H
#define HEADER_H

// 消息类型宏定义
#define MSG_TYPE_TURNON 0
#define MSG_TYPE_ENTERROOM 1
#define MSG_TYPE_CHANGEWIND 2
#define MSG_TYPE_CHANGETEMP 3
#define MSG_TYPE_CHANGEMODE 4   // 按照新需求，此命令没用
#define MSG_TYPE_SHOWCURRENTMONEY 5
#define MSG_TYPE_TURNOFF 13
#define MSG_TYPE_REWARM 14

#define MSG_TYPE_CREATERD 8 // 前台使用:打印详单
#define MSG_TYPE_CREATEIN 9 // 前台使用：打印账单

// 风速宏定义
#define FANSPEED_LOWWIND 1
#define FANSPEED_MIDDLEWIND 2
#define FANSPEED_HIGHWIND 3

// 模式宏定义
#define MODE_COOL 1
#define MODE_WARM 2
#define MODE_OFF 3  // 按照新需求，此命令没用

// 客户空调状态宏定义
#define STATE_RUNNING 100
#define STATE_PREEMPTED 101
#define STATE_DONE 102

#define MAX_TEMP 30
#define MIN_TEMP 16

#endif // HEADER_H
