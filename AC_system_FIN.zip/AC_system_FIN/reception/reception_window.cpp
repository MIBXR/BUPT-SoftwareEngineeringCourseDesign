#include "reception_window.h"
#include "ui_reception_window.h"

reception_window::reception_window(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::reception_window)
{
    ui->setupUi(this);
    setWindowTitle(tr("reception"));

    ui->reporttable_3->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);//自适应列宽
    connect(ui->printINButton,&QPushButton::clicked,this,&reception_window::on_PrintInvoice_clicked);
    connect(ui->printRDButton,&QPushButton::clicked,this,&reception_window::on_PrintRD_clicked);
}

reception_window::~reception_window()
{
    delete ui;
}

void reception_window::closeEvent(QCloseEvent *event)
{
    emit signal_windowClose();
}

void reception_window::on_CreatRD(int mRoomId, int mRequestStartTime, int mRequestEndTime, double mPartFee, int mWindSpeed, double mFeeRate)
{
    int iRow = ui->reporttable_3->rowCount();
    ui->reporttable_3->setRowCount(iRow+1);  // 在QTtableWidget增加一行数据

    // 对时间进行单位换算，d_xx表示状态持续时间

    QDateTime timestamp;
    timestamp.setTime_t(mRequestStartTime);
    int d_hour = ((mRequestEndTime - mRequestStartTime)) / 3600;
    int d_min = (mRequestEndTime - mRequestStartTime - d_hour * 3600) / 60;
    int d_sec = (mRequestEndTime - mRequestStartTime) - d_hour * 3600 - d_min * 60;

    QTableWidgetItem *ItemRoomId = new QTableWidgetItem(QString::number(mRoomId));
    QTableWidgetItem *ItemStartTime = new QTableWidgetItem(timestamp.toString(Qt::SystemLocaleShortDate));
    QTableWidgetItem *ItemDuration = new QTableWidgetItem(QString::number(d_hour) + "时" + QString::number(d_min) + "分" + QString::number(d_sec) + "秒");
    QTableWidgetItem *ItemWindSpeed;

    // 对风速进行相应换算表示
    switch (mWindSpeed) {
    case 1:
        ItemWindSpeed = new QTableWidgetItem("低速");
        break;
    case 2:
        ItemWindSpeed = new QTableWidgetItem("中速");
        break;
    case 3:
        ItemWindSpeed = new QTableWidgetItem("高速");
        break;
    }

    QTableWidgetItem *ItemFeeRate = new QTableWidgetItem(QString::number(mFeeRate));
    QTableWidgetItem *ItemPartFee = new QTableWidgetItem(QString::number(mPartFee));
    ItemRoomId->setTextAlignment(Qt::AlignCenter);
    ItemStartTime->setTextAlignment(Qt::AlignCenter);
    ItemDuration->setTextAlignment(Qt::AlignCenter);
    ItemWindSpeed->setTextAlignment(Qt::AlignCenter);
    ItemFeeRate->setTextAlignment(Qt::AlignCenter);
    ItemPartFee->setTextAlignment(Qt::AlignCenter);

    ui->reporttable_3->setItem(iRow, 0, ItemRoomId);
    ui->reporttable_3->setItem(iRow, 1, ItemStartTime);
    ui->reporttable_3->setItem(iRow, 2, ItemDuration);
    ui->reporttable_3->setItem(iRow, 3, ItemWindSpeed);
    ui->reporttable_3->setItem(iRow, 4, ItemFeeRate);
    ui->reporttable_3->setItem(iRow, 5, ItemPartFee);
}

void reception_window::on_CreatInvoice(int mRoomId, double mMoney, int mTimeIn, int mTimeOut){
    // 对起止时间进行单位换算
    QDateTime IN_timestamp,OUT_timestamp;
    IN_timestamp.setTime_t(mTimeIn);
    OUT_timestamp.setTime_t(mTimeOut);
    ui->inf_2->setText(IN_timestamp.toString(Qt::SystemLocaleShortDate) +"-"+OUT_timestamp.toString(Qt::SystemLocaleShortDate)+"\n"+ QString::number(mRoomId) +"号房间共消费" + QString::number(mMoney) + "元" );
}

// UI界面"详单"按钮被点击时产生的signal
void reception_window::on_RD_clicked()
{
    ui->reporttable_3->clearContents();
    ui->reporttable_3->setRowCount(0);
    int Roomid=ui->roomId_2->text().toInt();
    emit signal_CreateRD(Roomid);  // 清空详单对象
}

// UI界面"账单"界面被点击时产生的signal
void reception_window::on_eInvoice_clicked(){
    ui->inf_2->clear();
    int Roomid=ui->roomId_2->text().toInt();
    emit signal_CreateInvoice(Roomid);  // 清空账单对象


}

void reception_window::on_PrintRD_clicked(){
    emit signal_PrintRD(1);
}
void reception_window::on_PrintInvoice_clicked(){
    emit signal_PrintInvoice(1);
}
