#include "rd.h"

RD::RD(QObject *parent) : QObject(parent)
{

}

void RD::on_CreateRD(int mRoomId, int mRequestStartTime, int mRequestEndTime, double mPartFee, int mWindSpeed, double mFeeRate){
    // 对详单对象进行赋值
    Rd_List.append(QString::number(mRoomId));
    Rd_List.append(QString::number(mRequestStartTime));
    Rd_List.append(QString::number(mRequestEndTime));
    Rd_List.append(QString::number(mPartFee));
    Rd_List.append(QString::number(mWindSpeed));
    Rd_List.append(QString::number(mFeeRate));

}

void RD::on_clearRD(){
    Rd_List.clear();
}

void RD::on_PrintRD(){

   QFile file("rd.txt");  // 设置文件位置
   if (!file.open(QFile::WriteOnly | QFile::Text))
   {
       qDebug()<<"cannot open the file!";
   }
   QTextStream out(&file);
   for(int i=0; i<Rd_List.length();i++){
       switch ((i+1)%6) {
        case 0 : out <<tr("小计（元）：") << Rd_List[i].toDouble()<<"\n";break;
        case 1 : out <<tr("房间号：")<<Rd_List[i].toInt() << "\t";break;
        case 2 :
        {
           QDateTime timestamp;
           timestamp.setTime_t(Rd_List[i].toInt());
           out <<tr("请求时间：")<<timestamp.toString(Qt::SystemLocaleShortDate) << "\t";break;}

       case 3 :
       {
           int d_hour = ((Rd_List[i].toInt() - Rd_List[i-1].toInt())) / 3600;
           int d_min = (Rd_List[i].toInt() - Rd_List[i-1].toInt() - d_hour * 3600) / 60;
           int d_sec = (Rd_List[i].toInt() - Rd_List[i-1].toInt()) - d_hour * 3600 - d_min * 60;
           out <<tr("服务时长：")<<d_hour<<tr("时")<<d_min<<tr("分")<<d_sec<<tr("秒") << "\t";
           break;
       }
       case 4:{
           if(Rd_List[i].toInt()==1)
               out << tr("风速：") <<tr("低速\t");
           else if(Rd_List[i].toInt() == 2)
               out << tr("风速：") <<tr("中速\t");
           else if(Rd_List[i].toInt() == 3)
               out << tr("风速：") <<tr("高速\t");
            break;
       }
       case 5: out << tr("费率（元/分钟）:") << Rd_List[i].toDouble()<<"\t";break;

   }
}
}
RD::~RD(){

}


