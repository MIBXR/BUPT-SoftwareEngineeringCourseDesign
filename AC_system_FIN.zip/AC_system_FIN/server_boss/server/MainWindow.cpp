#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QAbstractItemView>
#include <QListWidget>
#include <QMessageBox>

MainWindow_Server::MainWindow_Server(QWidget* parent)
    : QWidget(parent)
    , ui(new Ui::MainWindow_Server)
{
    ui->setupUi(this);
    setWindowTitle(tr("服务器消息界面"));
    ui->btnSend->setEnabled(false);
    ui->btnStop->setEnabled(false);
    server = new WebSocketServerManager("Server", QWebSocketServer::NonSecureMode);

    //新连接进入
    connect(server, &WebSocketServerManager::signal_conncted, this, &MainWindow_Server::onConnected);

    //连接结束
    connect(server, &WebSocketServerManager::signal_disconncted, this, &MainWindow_Server::onDisconnected);

    //收到消息
    connect(server, &WebSocketServerManager::signal_textMessageReceived, this, &MainWindow_Server::onMessageReceived);

    //按下监听按钮
    connect(ui->btnListen,&QPushButton::clicked,this,&MainWindow_Server::onListenClicked);

    //按下停止监听按钮
    connect(ui->btnStop,&QPushButton::clicked,this,&MainWindow_Server::onStopClicked);

    //按下发送按钮
    connect(ui->btnSend,&QPushButton::clicked,this,&MainWindow_Server::onSendClicked);

}

void MainWindow_Server::onConnected(QString ip, qint32 port)
{
    ui->listWidget->addItem(QString("%1-%2").arg(ip).arg(port));
    count = 0;
    if (ui->listWidget->count() > 0)
        ui->btnSend->setEnabled(true);
}

void MainWindow_Server::onDisconnected(QString ip, qint32 port)
{
    QString line;
    for (int row = 0; row < ui->listWidget->count(); row++)
    {
        line = ui->listWidget->item(row)->text().section('-', 0, 0);
        if (ip == line)
            ui->listWidget->takeItem(row);
    }

    if (ui->listWidget->count() == 0)
        ui->btnSend->setEnabled(false);
}

QString MainWindow_Server:: findSpareRoom()
{
    return "1";
}

QJsonObject MainWindow_Server::String2Json(const QString& str)
{
    QJsonObject j_ret;

    QJsonParseError j_err;
    QJsonDocument j_doc = QJsonDocument::fromJson(str.toUtf8(), &j_err);
    if (j_err.error == QJsonParseError::NoError && j_doc.isObject())
        j_ret = j_doc.object();

    return j_ret;
}

QString MainWindow_Server::Json2String(const QJsonObject& json)
{
    QJsonDocument document;
    document.setObject(json);
    QByteArray byteArray = document.toJson(QJsonDocument::Compact);
    QString strJson(byteArray);

    return strJson;
}

void MainWindow_Server::onMessageReceived(QString ip, quint32 port, QString message)
{
    count++;
    QString text = QString("[%1-%2]: %3").arg(ip).arg(port).arg(message);
    ui->editRecv->append(text);

    qDebug() << "rec: " << message;

    QJsonObject jsonMessage = String2Json(message);
    QJsonObject jsonMessageSend;
    QJsonObject innerData;
    QJsonObject innerDataItem;
    QString inf; //声明一个接下来可能用的字段
    QString sendMessage;

    if (jsonMessage.contains("MsgType"))
    {
        QJsonValue value = jsonMessage.value("MsgType");
        qint8 msgType = value.toInt();

        switch (msgType)
        {
        case MSG_TYPE_TURNON:
            jsonMessageSend.insert("MsgType", QString::number(MSG_TYPE_TURNON, 10));
            jsonMessageSend.insert("Mode", QString::number(MODE_COOL, 10));
            jsonMessageSend.insert("WindSpeed", QString::number(FANSPEED_LOWWIND, 10));
            jsonMessageSend.insert("TargetTemp", QString::number(26, 10));
            jsonMessageSend.insert("FeeRate", QString::number(0.01, 'f', 2));

            break;
        case MSG_TYPE_ENTERROOM:
            jsonMessageSend.insert("MsgType", MSG_TYPE_ENTERROOM);
            jsonMessageSend.insert("RoomId", QString::number(1, 10));
            jsonMessageSend.insert("UserId", "123");
            break;
        case MSG_TYPE_CHANGEWIND:
            fee += 0.01;
            jsonMessageSend.insert("MsgType", MSG_TYPE_CHANGEWIND);
            jsonMessageSend.insert("FeeRate", QString::number(fee, 'f', 2));
            break;
        case MSG_TYPE_CHANGETEMP:
            inf = jsonMessage.value("UserId").toString();
            jsonMessageSend.insert("MsgType", MSG_TYPE_CHANGETEMP);
//            jsonMessageSend.insert("RoomId", findSpareRoom().toInt());
            jsonMessageSend.insert("Ack", "1");
            tmp++;
            jsonMessageSend.insert("UserId", inf);
            break;
        case MSG_TYPE_TURNOFF:
            tfee += 0.2;
            jsonMessageSend.insert("MsgType", MSG_TYPE_TURNOFF);
            jsonMessageSend.insert("Money", QString::number(tfee, 'f', 2));
            jsonMessageSend.insert("Duration", QString::number(65, 10));
        case MSG_TYPE_BEGINREQUEST:
            {//jsonMessageSend.insert("MsgType", 8);
            QList<QJsonObject> list;
            QJsonObject ReportItem;
            ReportItem.insert("RoomId","1");
            ReportItem.insert("OpenTime","2");
            ReportItem.insert("DispatchTime","3");
            ReportItem.insert("DetailNum","4");
            ReportItem.insert("WindChangeNum","5");
            ReportItem.insert("ServiceTime","6");
            ReportItem.insert("TotalFee","7.0");
             list.append(ReportItem);
            QJsonObject ReportItem1;
            ReportItem1.insert("RoomId","2");
            ReportItem1.insert("OpenTime","2");
            ReportItem1.insert("DispatchTime","3");
            ReportItem1.insert("DetailNum","4");
            ReportItem1.insert("WindChangeNum","5");
            ReportItem1.insert("ServiceTime","6");
            ReportItem1.insert("TotalFee","7.0");
            list.append(ReportItem1);
            QJsonObject ReportItem2;
            ReportItem2.insert("RoomId","3");
            ReportItem2.insert("OpenTime","2");
            ReportItem2.insert("DispatchTime","3");
            ReportItem2.insert("DetailNum","4");
            ReportItem2.insert("WindChangeNum","5");
            ReportItem2.insert("ServiceTime","6");
            ReportItem2.insert("TotalFee","7.0");
             list.append(ReportItem2);
            QString str="";

            for(int i = 0; i < list.length(); i++)
            {
                str += Json2String(list[i]) + "_";
            }
            str.chop(1);
            qDebug()<<"发送的数据:"<<str;
            jsonMessageSend.insert("Report",str);
            jsonMessageSend.insert("MsgType", MSG_TYPE_BEGINREQUEST);

            }break;
//            innerDataItem.insert("Temp","26");
//            innerDataItem.insert("WindSpeed",QString::number(slowSpeed));
//            innerDataItem.insert("Mode",QString::number(warmMode));
//            innerDataItem.insert("Cost","0.01");
//            innerDataItem.insert("PerFee","0.01");
//            innerDataItem.insert("TimeStart","1618633706");
//            innerDataItem.insert("TimeEnd","1618633767");
//            innerData.insert("0",innerDataItem);

//            innerDataItem.insert("Temp","27");
//            innerDataItem.insert("WindSpeed",QString::number(slowSpeed));
//            innerDataItem.insert("Mode",QString::number(warmMode));
//            innerDataItem.insert("Cost","0.015");
//            innerDataItem.insert("PerFee","0.015");
//            innerDataItem.insert("TimeStart","1618633767");
//            innerDataItem.insert("TimeEnd","1618633826");
//            innerData.insert("1",innerDataItem);

//            innerDataItem.insert("Temp","26");
//            innerDataItem.insert("WindSpeed",QString::number(highSpeed));
//            innerDataItem.insert("Mode",QString::number(warmMode));
//            innerDataItem.insert("Cost","1.38");
//            innerDataItem.insert("PerFee","0.02");
//            innerDataItem.insert("TimeStart","1618633826");
//            innerDataItem.insert("TimeEnd","1618637944");
//            innerData.insert("2",innerDataItem);

//            jsonMessageSend.insert("CostDetail", innerData);
            break;
//        case 5:
//            jsonMessageSend.insert("MsgType", 5);

//            innerDataItem.insert("RoomId","1");
//            innerDataItem.insert("IsOn",true);
//            innerDataItem.insert("Temp","26");
//            innerDataItem.insert("WindSpeed",QString::number(slowSpeed));
//            innerDataItem.insert("Mode",QString::number(warmMode));
//            innerData.insert("0",innerDataItem);

//            innerDataItem.insert("RoomId","2");
//            innerDataItem.insert("IsOn",true);
//            innerDataItem.insert("Temp","30");
//            innerDataItem.insert("WindSpeed",QString::number(slowSpeed));
//            innerDataItem.insert("Mode",QString::number(coldMode));
//            innerData.insert("1",innerDataItem);

//            innerDataItem.insert("RoomId","3");
//            innerDataItem.insert("IsOn",false);
//            innerData.insert("2",innerDataItem);

//            jsonMessageSend.insert("AirStatus", innerData);
//            break;
//        case 8:
//            jsonMessageSend.insert("MsgType", 8);
//            break;
        default:
            break;
        }
    }

    sendMessage = Json2String(jsonMessageSend);
    server->slot_sendData(ip, port, sendMessage);
    qDebug() << "send: " << sendMessage;
}

void MainWindow_Server::onListenClicked()
{
    qDebug() << "btnListen clicked";

    QString address = ui->editAddress->text();
    QString port = ui->editPort->text();

    server->slot_start(QHostAddress(address), port.toInt());
    if (server->running())
    {
        ui->btnListen->setEnabled(false);
        ui->btnStop->setEnabled(true);
    }
    else
    {
        ui->btnListen->setEnabled(true);
        ui->btnStop->setEnabled(false);
    }
}

void MainWindow_Server::onStopClicked()
{
    qDebug() << "btnStop clicked";

    server->slot_stop();
    if (server->running())
    {
        ui->btnListen->setEnabled(false);
        ui->btnStop->setEnabled(true);
    }
    else
    {
        ui->btnListen->setEnabled(true);
        ui->btnStop->setEnabled(false);
    }
}

void MainWindow_Server::onSendClicked()
{
    qDebug() << "btnSend clicked";

    if (!ui->listWidget->selectedItems().count())
    {
        QMessageBox::critical(NULL, "Error", "还未选择客户端");
        return;
    }
    else
    {
        for (int i = 0; i < ui->listWidget->selectedItems().count(); i++)
        {
            QString label = ui->listWidget->selectedItems()[i]->text();
            QString address = label.section('-', 0, 0);
            QString port = label.section('-', 1, 1);

            server->slot_sendData(address, port.toInt(), ui->editSend->toPlainText());
        }
    }
}

MainWindow_Server::~MainWindow_Server()
{
}


