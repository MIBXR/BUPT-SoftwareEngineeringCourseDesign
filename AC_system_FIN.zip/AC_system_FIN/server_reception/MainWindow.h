#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "connectthread.h"
#include "serverthread.h"
#include "websocketservermanager.h"
#include <QThread>
#include <QWebSocket>
#include <QWebSocketServer>
#include <QWidget>
#include <QJsonDocument>
#include <QJsonObject>

// 消息类型宏定义
#define MSG_TYPE_TURNON 0
#define MSG_TYPE_ENTERROOM 1
#define MSG_TYPE_CHANGEWIND 2
#define MSG_TYPE_CHANGETEMP 3
#define MSG_TYPE_CHANGEMODE 4   // 按照新需求，此命令没用
#define MSG_TYPE_SHOWCURRENTMONEY 5
#define MSG_TYPE_TURNOFF 13
#define MSG_TYPE_REWARM 14


#define MSG_TYPE_CREATERD 8 // 前台使用:打印详单
#define MSG_TYPE_CREATEIN 9 // 前台使用：打印账单

// 风速宏定义
#define FANSPEED_LOWWIND 1
#define FANSPEED_MIDDLEWIND 2
#define FANSPEED_HIGHWIND 3

// 模式宏定义
#define MODE_COOL 1
#define MODE_WARM 2
#define MODE_OFF 3  // 按照新需求，此命令没用

// 客户空调状态宏定义
#define STATE_RUNNING 100
#define STATE_PREEMPTED 101
#define STATE_DONE 102

#define MAX_TEMP 30
#define MIN_TEMP 16

QT_BEGIN_NAMESPACE
namespace Ui
{
class MainWindow_Server;
}
QT_END_NAMESPACE

class MainWindow_Server : public QWidget
{
    Q_OBJECT

public:
    MainWindow_Server(QWidget* parent = nullptr);
    ~MainWindow_Server();

private slots:
    void onConnected(QString ip, qint32 port);
    void onDisconnected(QString ip, qint32 port);
    void onMessageReceived(QString ip, quint32 port, QString message);
    void onListenClicked();
    void onStopClicked();
    void onSendClicked();
    void on_RDButton_clicked();
    void on_INButton_clicked();
private:
    qint8 tmp = 1;
    qint8 count = 0;
    double fee = 0.12;
    double tfee = 0.12;
    Ui::MainWindow_Server* ui;
    WebSocketServerManager* server;
    QJsonObject String2Json(const QString& str);    //QString到json的转换
    QString Json2String(const QJsonObject& json);   //json到Qstring的转换
    QString findSpareRoom();
};
#endif // MAINWINDOW_H
