#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QAbstractItemView>
#include <QListWidget>
#include <QMessageBox>

MainWindow_Server::MainWindow_Server(QWidget* parent)
    : QWidget(parent)
    , ui(new Ui::MainWindow_Server)
{
    ui->setupUi(this);
    setWindowTitle(tr("服务器消息界面"));
    ui->btnSend->setEnabled(false);
    ui->btnStop->setEnabled(false);
    server = new WebSocketServerManager("Server", QWebSocketServer::NonSecureMode);

    //新连接进入
    connect(server, &WebSocketServerManager::signal_conncted, this, &MainWindow_Server::onConnected);

    //连接结束
    connect(server, &WebSocketServerManager::signal_disconncted, this, &MainWindow_Server::onDisconnected);

    //收到消息
    connect(server, &WebSocketServerManager::signal_textMessageReceived, this, &MainWindow_Server::onMessageReceived);

    //按下监听按钮
    connect(ui->btnListen,&QPushButton::clicked,this,&MainWindow_Server::onListenClicked);

    //按下停止监听按钮
    connect(ui->btnStop,&QPushButton::clicked,this,&MainWindow_Server::onStopClicked);

    //按下发送按钮
    connect(ui->btnSend,&QPushButton::clicked,this,&MainWindow_Server::onSendClicked);
    //详单
    connect(ui->INButton,&QPushButton::clicked,this,&MainWindow_Server::on_INButton_clicked);
    connect(ui->RDButton,&QPushButton::clicked,this,&MainWindow_Server::on_RDButton_clicked);
}


void MainWindow_Server::on_RDButton_clicked(){
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType",8);
    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
}
void MainWindow_Server::on_INButton_clicked(){


}
void MainWindow_Server::onConnected(QString ip, qint32 port)
{
    ui->listWidget->addItem(QString("%1-%2").arg(ip).arg(port));
    count = 0;
    if (ui->listWidget->count() > 0)
        ui->btnSend->setEnabled(true);
}

void MainWindow_Server::onDisconnected(QString ip, qint32 port)
{
    QString line;
    for (int row = 0; row < ui->listWidget->count(); row++)
    {
        line = ui->listWidget->item(row)->text().section('-', 0, 0);
        if (ip == line)
            ui->listWidget->takeItem(row);
    }

    if (ui->listWidget->count() == 0)
        ui->btnSend->setEnabled(false);
}

QString MainWindow_Server:: findSpareRoom()
{
    return "1";
}

QJsonObject MainWindow_Server::String2Json(const QString& str)
{
    QJsonObject j_ret;

    QJsonParseError j_err;
    QJsonDocument j_doc = QJsonDocument::fromJson(str.toUtf8(), &j_err);
    if (j_err.error == QJsonParseError::NoError && j_doc.isObject())
        j_ret = j_doc.object();

    return j_ret;
}

QString MainWindow_Server::Json2String(const QJsonObject& json)
{
    QJsonDocument document;
    document.setObject(json);
    QByteArray byteArray = document.toJson(QJsonDocument::Compact);
    QString strJson(byteArray);

    return strJson;
}

void MainWindow_Server::onMessageReceived(QString ip, quint32 port, QString message)
{
    count++;
    QString text = QString("[%1-%2]: %3").arg(ip).arg(port).arg(message);
    ui->editRecv->append(text);

    qDebug() << "rec: " << message;

    QJsonObject jsonMessage = String2Json(message);
    QJsonObject jsonMessageSend;
    QJsonObject innerData;
    QJsonObject innerDataItem;
    QString inf; //声明一个接下来可能用的字段
    QString sendMessage;

    if (jsonMessage.contains("MsgType"))
    {
        QJsonValue value = jsonMessage.value("MsgType");
        qint8 msgType = value.toInt();

        switch (msgType)
        {

        case MSG_TYPE_CREATERD://详单
            {
            QList<QJsonObject> list;
            QJsonObject DetailItem;
            DetailItem.insert("RequestStartTime","123456");
            DetailItem.insert("RequestEndTime","1234567");
            DetailItem.insert("PartFee","2.11");
            DetailItem.insert("WindSpeed","1");
            DetailItem.insert("FeeRate","2.11");
            list.append(DetailItem);
            list.append(DetailItem);
            QString DetailStr = "";
            for(int i=0;i<list.length();i++){
                DetailStr += Json2String(list[i])+"_";
            }
            DetailStr.chop(1);
            qDebug()<<DetailStr;
            jsonMessageSend.insert("Detail",DetailStr);
            jsonMessageSend.insert("MsgType", MSG_TYPE_CREATERD);
            jsonMessageSend.insert("RoomId", 1);
            }break;
         case MSG_TYPE_CREATEIN:
            {jsonMessageSend.insert("MsgType", MSG_TYPE_CREATEIN);
            jsonMessageSend.insert("RoomId", "1");
            jsonMessageSend.insert("Money","2.11");
            jsonMessageSend.insert("InTime","1234");
            jsonMessageSend.insert("OutTime","123456");

            break;
        }
        default:
            break;
        }
    }

    sendMessage = Json2String(jsonMessageSend);
    server->slot_sendData(ip, port, sendMessage);
    qDebug() << "send: " << sendMessage;
}

void MainWindow_Server::onListenClicked()
{
    qDebug() << "btnListen clicked";

    QString address = ui->editAddress->text();
    QString port = ui->editPort->text();

    server->slot_start(QHostAddress(address), port.toInt());
    if (server->running())
    {
        ui->btnListen->setEnabled(false);
        ui->btnStop->setEnabled(true);
    }
    else
    {
        ui->btnListen->setEnabled(true);
        ui->btnStop->setEnabled(false);
    }
}

void MainWindow_Server::onStopClicked()
{
    qDebug() << "btnStop clicked";

    server->slot_stop();
    if (server->running())
    {
        ui->btnListen->setEnabled(false);
        ui->btnStop->setEnabled(true);
    }
    else
    {
        ui->btnListen->setEnabled(true);
        ui->btnStop->setEnabled(false);
    }
}

void MainWindow_Server::onSendClicked()
{
    qDebug() << "btnSend clicked";

    if (!ui->listWidget->selectedItems().count())
    {
        QMessageBox::critical(NULL, "Error", "还未选择客户端");
        return;
    }
    else
    {
        for (int i = 0; i < ui->listWidget->selectedItems().count(); i++)
        {
            QString label = ui->listWidget->selectedItems()[i]->text();
            QString address = label.section('-', 0, 0);
            QString port = label.section('-', 1, 1);

            server->slot_sendData(address, port.toInt(), ui->editSend->toPlainText());
        }
    }
}

MainWindow_Server::~MainWindow_Server()
{
}


