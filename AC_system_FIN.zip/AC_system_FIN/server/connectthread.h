#ifndef CONNECTTHREAD_H
#define CONNECTTHREAD_H

#include <QObject>
#include <QThread>
#include <QWebSocket>

class ConnectThread : public QObject
{
    Q_OBJECT
public:
    ConnectThread(QWebSocket* socket);
signals:
    void sgn_recvMessage(QString msg);
};

#endif // CONNECTTHREAD_H
