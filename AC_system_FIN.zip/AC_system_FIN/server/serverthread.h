#ifndef SERVERTHREAD_H
#define SERVERTHREAD_H

#include <QObject>
#include <QWebSocket>
#include <QWebSocketServer>

class ServerThread : public QObject
{
    Q_OBJECT
public:
    ServerThread();
    void closeServer();
    bool startListen(QHostAddress&, quint16);

private:
    QWebSocketServer* server;

signals:
    void sgn_newConnect(QWebSocket*);
};

#endif // SERVERTHREAD_H
