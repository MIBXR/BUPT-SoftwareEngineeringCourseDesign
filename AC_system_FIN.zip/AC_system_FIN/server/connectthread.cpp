#include "connectthread.h"

ConnectThread::ConnectThread(QWebSocket* socket)
{
    //    收到消息
    connect(socket, &QWebSocket::textMessageReceived, [this](const QString& msg) {
        qDebug() << "fuckrecv " << msg;
        emit sgn_recvMessage(msg);
    });
    //发送消息
    //    connect(this, &WebSocketServer::sendMessage, socket, &QWebSocket::sendTextMessage);
    //    //断开连接，释放
    //    connect(socket, &QWebSocket::disconnected, [this, socket]() {
    //        clientList.removeAll(socket);
    //        socket->deleteLater();
    //    });
}
