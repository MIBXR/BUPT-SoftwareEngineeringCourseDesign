#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QAbstractItemView>
#include <QListWidget>
#include <QMessageBox>

MainWindow_Server::MainWindow_Server(QWidget* parent)
    : QWidget(parent)
    , ui(new Ui::MainWindow_Server)
{
    ui->setupUi(this);
    setWindowTitle(tr("服务器消息界面"));
    ui->btnSend->setEnabled(false);
    ui->btnStop->setEnabled(false);
    server = new WebSocketServerManager("Server", QWebSocketServer::NonSecureMode);

    //新连接进入
    connect(server, &WebSocketServerManager::signal_conncted, this, &MainWindow_Server::onConnected);

    //连接结束
    connect(server, &WebSocketServerManager::signal_disconncted, this, &MainWindow_Server::onDisconnected);

    //收到消息
    connect(server, &WebSocketServerManager::signal_textMessageReceived, this, &MainWindow_Server::onMessageReceived);

    //按下监听按钮
    connect(ui->btnListen,&QPushButton::clicked,this,&MainWindow_Server::onListenClicked);

    //按下停止监听按钮
    connect(ui->btnStop,&QPushButton::clicked,this,&MainWindow_Server::onStopClicked);

    //按下发送按钮
    connect(ui->btnSend,&QPushButton::clicked,this,&MainWindow_Server::onSendClicked);

}

void MainWindow_Server::onConnected(QString ip, qint32 port)
{
    ui->listWidget->addItem(QString("%1-%2").arg(ip).arg(port));
    count = 0;
    if (ui->listWidget->count() > 0)
        ui->btnSend->setEnabled(true);
}

void MainWindow_Server::onDisconnected(QString ip, qint32 port)
{
    QString line;
    for (int row = 0; row < ui->listWidget->count(); row++)
    {
        line = ui->listWidget->item(row)->text().section('-', 0, 0);
        if (ip == line)
            ui->listWidget->takeItem(row);
    }

    if (ui->listWidget->count() == 0)
        ui->btnSend->setEnabled(false);
}

QString MainWindow_Server:: findSpareRoom()
{
    return "1";
}

QJsonObject MainWindow_Server::String2Json(const QString& str)
{
    QJsonObject j_ret;

    QJsonParseError j_err;
    QJsonDocument j_doc = QJsonDocument::fromJson(str.toUtf8(), &j_err);
    if (j_err.error == QJsonParseError::NoError && j_doc.isObject())
        j_ret = j_doc.object();

    return j_ret;
}

QString MainWindow_Server::Json2String(const QJsonObject& json)
{
    QJsonDocument document;
    document.setObject(json);
    QByteArray byteArray = document.toJson(QJsonDocument::Compact);
    QString strJson(byteArray);

    return strJson;
}

void MainWindow_Server::onMessageReceived(QString ip, quint32 port, QString message)
{
    count++;
    QString text = QString("[%1-%2]: %3").arg(ip).arg(port).arg(message);
    ui->editRecv->append(text);

    qDebug() << "rec: " << message;

    QJsonObject jsonMessage = String2Json(message);
    QJsonObject jsonMessageSend;
    QJsonObject innerData;
    QJsonObject innerDataItem;
    QString inf; //声明一个接下来可能用的字段
    QString sendMessage;

    if (jsonMessage.contains("MsgType"))
    {
        QJsonValue value = jsonMessage.value("MsgType");
        qint8 msgType = value.toInt();

        switch (msgType)
        {
        case MSG_TYPE_TURNON:
            jsonMessageSend.insert("MsgType", QString::number(MSG_TYPE_TURNON, 10));
            jsonMessageSend.insert("Mode", QString::number(MODE_COOL, 10));
            jsonMessageSend.insert("WindSpeed", QString::number(FANSPEED_LOWWIND, 10));
            jsonMessageSend.insert("TargetTemp", QString::number(26, 10));
            jsonMessageSend.insert("FeeRate", QString::number(0.01, 'f', 2));

            break;
        case MSG_TYPE_ENTERROOM:
            jsonMessageSend.insert("MsgType", MSG_TYPE_ENTERROOM);
            jsonMessageSend.insert("RoomId", QString::number(1, 10));
            jsonMessageSend.insert("UserId", "123");
            break;
        case MSG_TYPE_CHANGEWIND:
            fee += 0.01;
            jsonMessageSend.insert("MsgType", MSG_TYPE_CHANGEWIND);
            jsonMessageSend.insert("FeeRate", QString::number(fee, 'f', 2));
            break;
        case MSG_TYPE_CHANGETEMP:
            inf = jsonMessage.value("UserId").toString();
            jsonMessageSend.insert("MsgType", MSG_TYPE_CHANGETEMP);
//            jsonMessageSend.insert("RoomId", findSpareRoom().toInt());
            jsonMessageSend.insert("Ack", "1");
            tmp++;
            jsonMessageSend.insert("UserId", inf);
            break;
        case MSG_TYPE_TURNOFF:
            tfee += 0.2;
            jsonMessageSend.insert("MsgType", MSG_TYPE_TURNOFF);
            jsonMessageSend.insert("Money", QString::number(tfee, 'f', 2));
            jsonMessageSend.insert("Duration", QString::number(65, 10));
            break;
        case 14:
            return;
            break;
        case 100:
            return;
            break;
        case 101:
            return;
            break;
        case 102:
            return;
            break;
        case MSG_TYPE_SETPARA:
            jsonMessageSend.insert("MsgType", MSG_TYPE_SETPARA);
            jsonMessageSend.insert("Ack", "1");
            break;
        case MSG_TYPE_CREATERD://详单
            {
            QJsonObject AllDetailItems;

            QJsonObject DetailItem;

            DetailItem.insert("RequestStartTime","123456");
            DetailItem.insert("RequestEndTime","1234567");
            DetailItem.insert("PartFee","2.11");
            DetailItem.insert("WindSpeed","1");
            DetailItem.insert("FeeRate","2.11");

            AllDetailItems.insert("1",DetailItem);
            AllDetailItems.insert("2",DetailItem);
            AllDetailItems.insert("3",DetailItem);
            AllDetailItems.insert("4",DetailItem);
            AllDetailItems.insert("5",DetailItem);
            AllDetailItems.insert("6",DetailItem);
            AllDetailItems.insert("7",DetailItem);
            AllDetailItems.insert("8",DetailItem);
            AllDetailItems.insert("9",DetailItem);
            AllDetailItems.insert("10",DetailItem);

            jsonMessageSend.insert("Detail", AllDetailItems);
            jsonMessageSend.insert("MsgType", MSG_TYPE_CREATERD);
            }
            break;
         case MSG_TYPE_CREATEIN:
            {
            jsonMessageSend.insert("MsgType", MSG_TYPE_CREATEIN);
            jsonMessageSend.insert("RoomId", "1");
            jsonMessageSend.insert("Money","2.11");
            jsonMessageSend.insert("InTime","1234");
            jsonMessageSend.insert("OutTime","123456");
            }
            break;
        case MSG_TYPE_BEGINREQUEST:
            {
            QJsonObject AllReportItems;
            QJsonObject ReportItem;
            ReportItem.insert("RoomId","1");
            ReportItem.insert("OpenTime","2");
            ReportItem.insert("DispatchTime","3");
            ReportItem.insert("DetailNum","4");
            ReportItem.insert("WindChangeNum","5");
            ReportItem.insert("ServiceTime","6");
            ReportItem.insert("TotalFee","7.0");

            AllReportItems.insert("1",ReportItem);
            AllReportItems.insert("2",ReportItem);
            AllReportItems.insert("3",ReportItem);
            AllReportItems.insert("4",ReportItem);
            AllReportItems.insert("5",ReportItem);
            AllReportItems.insert("6",ReportItem);
            AllReportItems.insert("7",ReportItem);
            AllReportItems.insert("8",ReportItem);
            AllReportItems.insert("9",ReportItem);
            AllReportItems.insert("10",ReportItem);

            jsonMessageSend.insert("Report",AllReportItems);
            jsonMessageSend.insert("MsgType", MSG_TYPE_BEGINREQUEST);

            }break;

        case MSG_TYPE_CHECKROOMSTATE:
            jsonMessageSend.insert("MsgType", MSG_TYPE_CHECKROOMSTATE);

            QJsonObject AllRooms;

            QJsonObject RoomOne;
            QJsonObject RoomTwo;
            QJsonObject RoomThree;
            QJsonObject RoomFour;
            QJsonObject RoomFive;

            RoomOne.insert("RoomId", QString::number(1, 10));
            RoomOne.insert("RoomTemp", QString::number(1, 10));
            RoomOne.insert("TargetTemp", QString::number(2 + flag, 10));
            RoomOne.insert("TargetTemp", QString::number(2 + flag, 10));
            RoomOne.insert("WindSpeed", QString::number(2, 10));
            RoomOne.insert("Money", QString::number(2, 10));
            RoomOne.insert("ServiceDuration", QString::number(1, 10));
            RoomOne.insert("WaitingDuration", QString::number(1, 10));
            RoomOne.insert("State", QString::number(101, 10));

            RoomTwo.insert("RoomId", QString::number(2, 10));
            RoomTwo.insert("RoomTemp", QString::number(1, 10));
            RoomTwo.insert("TargetTemp", QString::number(2, 10));
            RoomTwo.insert("TargetTemp", QString::number(2, 10));
            RoomTwo.insert("WindSpeed", QString::number(2, 10));
            RoomTwo.insert("Money", QString::number(2, 10));
            RoomTwo.insert("ServiceDuration", QString::number(1, 10));
            RoomTwo.insert("WaitingDuration", QString::number(1, 10));
            RoomTwo.insert("State", QString::number(101, 10));

            RoomThree.insert("RoomId", QString::number(3, 10));
            RoomThree.insert("RoomTemp", QString::number(1, 10));
            RoomThree.insert("TargetTemp", QString::number(2, 10));
            RoomThree.insert("TargetTemp", QString::number(2, 10));
            RoomThree.insert("WindSpeed", QString::number(2, 10));
            RoomThree.insert("Money", QString::number(2, 10));
            RoomThree.insert("ServiceDuration", QString::number(1, 10));
            RoomThree.insert("WaitingDuration", QString::number(1, 10));
            RoomThree.insert("State", QString::number(101, 10));

            RoomFour.insert("RoomId", QString::number(4, 10));
            RoomFour.insert("RoomTemp", QString::number(1, 10));
            RoomFour.insert("TargetTemp", QString::number(2, 10));
            RoomFour.insert("TargetTemp", QString::number(2, 10));
            RoomFour.insert("WindSpeed", QString::number(2, 10));
            RoomFour.insert("Money", QString::number(2, 10));
            RoomFour.insert("ServiceDuration", QString::number(1, 10));
            RoomFour.insert("WaitingDuration", QString::number(1, 10));
            RoomFour.insert("State", QString::number(101, 10));

            if (flag == 1)
            {
            RoomFive.insert("RoomId", QString::number(5, 10));
            RoomFive.insert("RoomTemp", QString::number(1, 10));
            RoomFive.insert("TargetTemp", QString::number(2, 10));
            RoomFive.insert("TargetTemp", QString::number(2, 10));
            RoomFive.insert("WindSpeed", QString::number(2, 10));
            RoomFive.insert("Money", QString::number(2, 10));
            RoomFive.insert("ServiceDuration", QString::number(1, 10));
            RoomFive.insert("WaitingDuration", QString::number(1, 10));
            RoomFive.insert("State", QString::number(101, 10));
            }


            AllRooms.insert("1",RoomOne);
            AllRooms.insert("2",RoomTwo);
            AllRooms.insert("3",RoomThree);
            AllRooms.insert("4",RoomFour);
            if (flag == 1)
            {
            AllRooms.insert("5",RoomFive);
            }

            flag = ( flag + 1 ) % 2;
            jsonMessageSend.insert("AllRooms", AllRooms);
            break;
        }
    }

    sendMessage = Json2String(jsonMessageSend);
    server->slot_sendData(ip, port, sendMessage);
    qDebug() << "send: " << sendMessage;
}

void MainWindow_Server::onListenClicked()
{
    qDebug() << "btnListen clicked";

    QString address = ui->editAddress->text();
    QString port = ui->editPort->text();

    server->slot_start(QHostAddress(address), port.toInt());
    if (server->running())
    {
        ui->btnListen->setEnabled(false);
        ui->btnStop->setEnabled(true);
    }
    else
    {
        ui->btnListen->setEnabled(true);
        ui->btnStop->setEnabled(false);
    }
}

void MainWindow_Server::onStopClicked()
{
    qDebug() << "btnStop clicked";

    server->slot_stop();
    if (server->running())
    {
        ui->btnListen->setEnabled(false);
        ui->btnStop->setEnabled(true);
    }
    else
    {
        ui->btnListen->setEnabled(true);
        ui->btnStop->setEnabled(false);
    }
}

void MainWindow_Server::onSendClicked()
{
    qDebug() << "btnSend clicked";

    if (!ui->listWidget->selectedItems().count())
    {
        QMessageBox::critical(NULL, "Error", "还未选择客户端");
        return;
    }
    else
    {
        for (int i = 0; i < ui->listWidget->selectedItems().count(); i++)
        {
            QString label = ui->listWidget->selectedItems()[i]->text();
            QString address = label.section('-', 0, 0);
            QString port = label.section('-', 1, 1);

            server->slot_sendData(address, port.toInt(), ui->editSend->toPlainText());
        }
    }
}

MainWindow_Server::~MainWindow_Server()
{
}



void MainWindow_Server::on_pushButton_clicked()
{
    if (!ui->listWidget->selectedItems().count())
    {
        QMessageBox::critical(NULL, "Error", "还未选择客户端");
        return;
    }
    else
    {
        for (int i = 0; i < ui->listWidget->selectedItems().count(); i++)
        {
            QString label = ui->listWidget->selectedItems()[i]->text();
            QString address = label.section('-', 0, 0);
            QString port = label.section('-', 1, 1);
            QJsonObject jsonMessageSend;
            jsonMessageSend.insert("MsgType", 100);
            server->slot_sendData(address, port.toInt(), Json2String(jsonMessageSend));
        }
    }
}

void MainWindow_Server::on_pushButton_2_clicked()
{
    if (!ui->listWidget->selectedItems().count())
    {
        QMessageBox::critical(NULL, "Error", "还未选择客户端");
        return;
    }
    else
    {
        for (int i = 0; i < ui->listWidget->selectedItems().count(); i++)
        {
            QString label = ui->listWidget->selectedItems()[i]->text();
            QString address = label.section('-', 0, 0);
            QString port = label.section('-', 1, 1);
            QJsonObject jsonMessageSend;
            jsonMessageSend.insert("MsgType", 101);
            server->slot_sendData(address, port.toInt(), Json2String(jsonMessageSend));
        }
    }
}

void MainWindow_Server::on_pushButton_3_clicked()
{
    if (!ui->listWidget->selectedItems().count())
    {
        QMessageBox::critical(NULL, "Error", "还未选择客户端");
        return;
    }
    else
    {
        for (int i = 0; i < ui->listWidget->selectedItems().count(); i++)
        {
            QString label = ui->listWidget->selectedItems()[i]->text();
            QString address = label.section('-', 0, 0);
            QString port = label.section('-', 1, 1);
            QJsonObject jsonMessageSend;
            jsonMessageSend.insert("MsgType", 102);
            server->slot_sendData(address, port.toInt(), Json2String(jsonMessageSend));
        }
    }
}

void MainWindow_Server::on_pushButton_4_clicked()
{
    if (!ui->listWidget->selectedItems().count())
    {
        QMessageBox::critical(NULL, "Error", "还未选择客户端");
        return;
    }
    else
    {
        for (int i = 0; i < ui->listWidget->selectedItems().count(); i++)
        {
            QString label = ui->listWidget->selectedItems()[i]->text();
            QString address = label.section('-', 0, 0);
            QString port = label.section('-', 1, 1);
            tfee += 0.2;
            temp -= 0.1;
            QJsonObject jsonMessageSend;
            jsonMessageSend.insert("MsgType", 5);
            jsonMessageSend.insert("Money", QString::number(tfee, 'f', 2));
            jsonMessageSend.insert("RoomTemp", QString::number(temp, 'f', 2));

            server->slot_sendData(address, port.toInt(), Json2String(jsonMessageSend));
        }
    }
}
