#ifndef clientthread_H
#define clientthread_H
#include <QDebug>
#include <QObject>
#include <QThread>
#include <QTime>
#include <QWidget>
#include <QtWebSockets>
#include <winsock2.h>

class clientthread : public QObject
{
    Q_OBJECT
public:
    clientthread();
    ~clientthread();

public:
    void openClient(QUrl url);
    void closeClient();
    void sendMessage(QString text);
    QString getAddress();
    QString getPort();

private:
    QString thread_msg;
    QWebSocket* client;

signals:
    void sgn_connected();
    void sgn_disconnected();
    void sgn_recvMessage(QString msg);
};

#endif // clientthread_H
