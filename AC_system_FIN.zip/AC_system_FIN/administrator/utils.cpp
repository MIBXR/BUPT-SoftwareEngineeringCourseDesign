#include <utils.h>

QString getWindStr(int FanSpeed)
{
    switch(FanSpeed)
    {
    case FANSPEED_LOWWIND:
        return "低";
    case FANSPEED_MIDDLEWIND:
        return "中";
    case FANSPEED_HIGHWIND:
        return "高";
    default:
        return "error";
    }
}

QString getModeStr(int Mode)
{
    switch(Mode)
    {
    case MODE_COOL:
        return "制冷";
    case MODE_WARM:
        return "制热";
    case MODE_OFF:
        return "关闭";
    default:
        return "error";
    }
}

QString getStateStr(int State)
{
    switch(State)
    {
    case STATE_RUNNING:
        return "运行中";
    case STATE_PREEMPTED:
        return "等待/抢占";
    case STATE_DONE:
        return "完成";
    default:
        return "error";
    }
}

QJsonObject String2Json(const QString& str)
{
    QJsonObject j_ret;

    QJsonParseError j_err;
    QJsonDocument j_doc = QJsonDocument::fromJson(str.toUtf8(), &j_err);
    if (j_err.error == QJsonParseError::NoError && j_doc.isObject())
        j_ret = j_doc.object();

    return j_ret;
}

QString Json2String(const QJsonObject& json)
{
    QJsonDocument document;
    document.setObject(json);
    QByteArray byteArray = document.toJson(QJsonDocument::Compact);
    QString strJson(byteArray);

    return strJson;
}
