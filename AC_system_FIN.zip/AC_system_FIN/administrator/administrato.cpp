#include "administrator_window.h"
#include "ui_administrator_window.h"

administrator_window::administrator_window(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::administrator_window)
{
    ui->setupUi(this);
    setWindowTitle(tr("administrator"));
    ui->infotable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);//����Ӧ�п�
    ui->infotable->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);// ����Ӧ�и�
    ui->ACstate->setText("关机");
    ui->ModecomboBox_4->setEnabled(false);
    ui->DefaultFanBox_4->setEnabled(false);
    ui->DefaultTempEdit_4->setEnabled(false);
    ui->TempLowEdit_4->setEnabled(false);
    ui->TempHighEdit_4->setEnabled(false);
    ui->FanLEdit_4->setEnabled(false);
    ui->FanMEdit_4->setEnabled(false);
    ui->FanHEdit_4->setEnabled(false);
    ui->setPara->setEnabled(false);
    ui->StartUp->setEnabled(false);
    ui->CheckRoomState->setEnabled(false);
}

administrator_window::~administrator_window()
{
    delete ui;
}

void administrator_window::closeEvent(QCloseEvent *event)
{
    emit signal_windowClose();
}

void administrator_window::on_PowerOn()
{
    ui->ACstate->setText("设定参数..");
    ui->ModecomboBox_4->setEnabled(true);
    ui->DefaultFanBox_4->setEnabled(true);
    ui->DefaultTempEdit_4->setEnabled(true);
    ui->TempLowEdit_4->setEnabled(true);
    ui->TempHighEdit_4->setEnabled(true);
    ui->FanLEdit_4->setEnabled(true);
    ui->FanMEdit_4->setEnabled(true);
    ui->FanHEdit_4->setEnabled(true);
    ui->powerOn->setEnabled(false);
    ui->setPara->setEnabled(true);
}

void administrator_window::on_setPara()
{
    ui->ACstate->setText("参数设定完毕");
    ui->ModecomboBox_4->setEnabled(false);
    ui->DefaultFanBox_4->setEnabled(false);
    ui->DefaultTempEdit_4->setEnabled(false);
    ui->TempLowEdit_4->setEnabled(false);
    ui->TempHighEdit_4->setEnabled(false);
    ui->FanLEdit_4->setEnabled(false);
    ui->FanMEdit_4->setEnabled(false);
    ui->FanHEdit_4->setEnabled(false);
    ui->setPara->setEnabled(false);
    ui->StartUp->setEnabled(true);
}
void administrator_window::on_StartUp()
{
    ui->ACstate->setText("Running");//�����ҵĵ��������� utf8���ܱ༭ ���Ժ�������������������Ҫ�޸�
    ui->StartUp->setEnabled(false);
    ui->CheckRoomState->setEnabled(true);
}
void administrator_window::on_CheckRoomState(qint8 mRoomId , double mRoomTemp,qint8 mTargetTemp , qint8 mWindSpeed,
                                              double mMoney , qint8 mServiceDuration,qint8 mWaitingDuration , qint8 mState)
{
     int numofrow = ui->infotable->rowCount();
     if(numofrow <= 5)
        ui->infotable->insertRow(numofrow);
     int flag = 0;
     flag = numofrow + 1;

     ui->infotable->setItem(flag - 1,0,new QTableWidgetItem(QString::number(mRoomId)));
     ui->infotable->setItem(flag - 1,1,new QTableWidgetItem(QString::number(mRoomTemp)));
     ui->infotable->setItem(flag - 1,2,new QTableWidgetItem(QString::number(mTargetTemp)));

     switch (mWindSpeed){
     case 1:
         ui->infotable->setItem(flag - 1,3,new QTableWidgetItem("low"));
         break;
     case 2:
         ui->infotable->setItem(flag - 1,3,new QTableWidgetItem("mid"));
         break;
     case 3:
         ui->infotable->setItem(flag - 1,3,new QTableWidgetItem("high"));//������Ҫ���������Ի�Ϊ����
         break;
     default:
         break;
     }

     ui->infotable->setItem(flag - 1,4,new QTableWidgetItem(QString::number(mMoney)));
     ui->infotable->setItem(flag - 1,5,new QTableWidgetItem(QString::number(mServiceDuration)));
     ui->infotable->setItem(flag - 1,6,new QTableWidgetItem(QString::number(mWaitingDuration)));
     switch (mState) {
     case 100:
         ui->infotable->setItem(flag - 1,7,new QTableWidgetItem("Running"));
         break;
     case 101:
         ui->infotable->setItem(flag - 1,7,new QTableWidgetItem("Seizing"));
         break;
     case 102:
         ui->infotable->setItem(flag - 1,7,new QTableWidgetItem("Service completed"));//������Ҫ���������Ի�Ϊ����
         break;
     default:
         break;
     }

     ui->infotable->item(flag - 1,0)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
     ui->infotable->item(flag - 1,1)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
     ui->infotable->item(flag - 1,2)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
     ui->infotable->item(flag - 1,3)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
     ui->infotable->item(flag - 1,4)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
     ui->infotable->item(flag - 1,5)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
     ui->infotable->item(flag - 1,6)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
     ui->infotable->item(flag - 1,7)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);

}

void administrator_window::on_powerOn_clicked()
{
    emit signal_PowerOn();
}

void administrator_window::on_setPara_clicked()
{
    int Mode;
    int DefaultSpeed;
    int DefaultTargetTemp;
    int TempHighLimit;
    int TempLowLimit;
    double FeeRateH;
    double FeeRateM;
    double FeeRateL;

    Mode = ui->ModecomboBox_4->currentIndex() + 1;//����Ϊ1������Ϊ2
    DefaultSpeed = ui->DefaultFanBox_4->currentIndex() + 1;//�ͷ�Ϊ1���з�Ϊ2���߷�Ϊ3
    DefaultTargetTemp = ui->DefaultTempEdit_4->text().toInt();
    TempHighLimit = ui->TempHighEdit_4->text().toInt();
    TempLowLimit = ui->TempLowEdit_4->text().toInt();
    FeeRateH = ui->FanHEdit_4->text().toDouble();
    FeeRateL = ui->FanLEdit_4->text().toDouble();
    FeeRateM = ui->FanMEdit_4->text().toDouble();

    emit signal_setPara(Mode, DefaultTargetTemp, TempHighLimit, TempLowLimit, FeeRateH, FeeRateM, FeeRateL,DefaultSpeed);  // 从控件中获取参数，填��..
}

void administrator_window::on_StartUp_clicked()
{
    emit signal_StartUp();
}

void administrator_window::on_CheckRoomState_clicked()
{
    emit signal_CheckRoomState();
}

void administrator_window::on_ClearContext()
{
    int rowNum =  ui->infotable->rowCount();
    for(int i = rowNum -1;i>=0 ;i--)
      {
          ui->infotable->removeRow(i);
      }
}
