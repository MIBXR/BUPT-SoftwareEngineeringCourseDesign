/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * monitoredobject
 *
 * 模块功能:
 * 用于监控对象
 *
 * Created on 2021/6/5.
 * @author hbw1112@foxmail.com (Huang Bowei)
 *
 * Edited on 2021/6/15.
 * @author hbw1112@foxmail.com (Huang Bowei)
 *
 */
#ifndef MONITOREDOBJECT_H
#define MONITOREDOBJECT_H

#include <QUrl>
#include <QWidget>
#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <clientthread.h>
#include <header.h>

class monitoredobject : public QObject
{
    Q_OBJECT
public:
    void getServiceId(int id);
private:
    int Service_id;

};


#endif // MONITOREDOBJECT_H
