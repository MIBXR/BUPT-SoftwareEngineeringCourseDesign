/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * administrator_controller
 *
 * 模块功能:
 * 用于接收管理员请求控制器类
 *
 * Created on 2021/6/5.
 * @author hbw1112@foxmail.com (Huang Bowei)
 *
 * Edited on 2021/6/15.
 * @author hbw1112@foxmail.com (Huang Bowei)
 *
 */
#ifndef ADMINISTRATOR_CONTROLLER_H
#define ADMINISTRATOR_CONTROLLER_H

#include <QUrl>
#include <QWidget>
#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <clientthread.h>
#include <administrator_window.h>
#include <header.h>

QT_BEGIN_NAMESPACE
namespace Ui { class administrator_controller; }
QT_END_NAMESPACE

class administrator_controller : public QWidget
{
    Q_OBJECT

public:
    administrator_controller(QWidget *parent = nullptr);
    ~administrator_controller();

private:
    Ui::administrator_controller *ui;
    clientthread* connect_thread;   //通信实体
    administrator_window* administratorWindow;  //界面实体
    QTimer *timer=new QTimer(this);
    int mRoomId;
    double mRoomTemp;
    int mTargetTemp;
    int mWindSpeed;
    double mMoney;
    int mServiceDuration;
    int mWaitingDuration;
    int mState;


signals:
    // 这里填控制器层到UI层的信号
    void signal_PowerOn();
    void signal_setPara();
    void signal_StartUp();
    void signal_CheckRoomState(int mRoomId , double mRoomTemp,int mTargetTemp , int mWindSpeed,
                               double mMoney , int mServiceDuration,int mWaitingDuration , int mState);
    void signal_ClearContext();

private slots:
    // 这里填UI层到控制器层的消息对应的槽函数
    void on_PowerOn();
    void on_setPara(int Mode, int DefaultTargetTemp,int TempHighLimit, int TempLowLimit, double FeeRateH, double FeeRateM, double FeeRateL,int DefaultSpeed);
    void on_StartUp();
    void on_CheckRoomState();

    // 这里是QT自动生成的槽函数
    void on_btnOpen_clicked();

    // 这里是其他槽函数
    void messageFromServer(QString message);    //服务器传来消息
    void subWindowClosed(); // 子界面关闭
};
#endif // ADMINISTRATOR_CONTROLLER_H
