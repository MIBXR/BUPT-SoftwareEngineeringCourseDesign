#include "administrator_controller.h"
#include "ui_administrator_controller.h"

administrator_controller::administrator_controller(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::administrator_controller)
{
    ui->setupUi(this);
    connect_thread = new clientthread();

    setWindowTitle(tr("loading..."));

    //新建数据传输对象与操作界面对象
    connect_thread = new clientthread();
    administratorWindow = new administrator_window();

    connect(administratorWindow, &administrator_window::signal_windowClose, this, &administrator_controller::subWindowClosed);

    //Socket连接状态
    connect(connect_thread, &clientthread::sgn_connected, this, [=]() {
        administratorWindow->show();
        qDebug() << "Client connected";
        this->hide();
    });
    connect(connect_thread, &clientthread::sgn_disconnected, this, [=]() {
        qDebug() << "Client disconnected";
        this->show();
    });

    // 应用逻辑层到控制器层的消息（接收来自服务器的数据并处理）
    connect(connect_thread, &clientthread::sgn_recvMessage, this, &administrator_controller::messageFromServer);

    // UI层到控制器层的消息
    connect(administratorWindow, &administrator_window::signal_PowerOn, this, &administrator_controller::on_PowerOn);
    connect(administratorWindow, &administrator_window::signal_setPara, this, &administrator_controller::on_setPara);
    connect(administratorWindow, &administrator_window::signal_StartUp, this, &administrator_controller::on_StartUp);
    connect(administratorWindow, &administrator_window::signal_CheckRoomState, this, &administrator_controller::on_CheckRoomState);

    // 控制器层到UI层的消息
    connect(this, &administrator_controller::signal_PowerOn, administratorWindow, &administrator_window::on_PowerOn);
    connect(this, &administrator_controller::signal_setPara, administratorWindow, &administrator_window::on_setPara);
    connect(this, &administrator_controller::signal_StartUp, administratorWindow, &administrator_window::on_StartUp);
    connect(this, &administrator_controller::signal_CheckRoomState, administratorWindow, &administrator_window::on_CheckRoomState);
    connect(this, &administrator_controller::signal_ClearContext, administratorWindow, &administrator_window::on_ClearContext);

    // 定时器和CheckRoomState的绑定
    connect(timer,SIGNAL(timeout()),this,SLOT(on_CheckRoomState()));
}

administrator_controller::~administrator_controller()
{
    delete ui;
}

void administrator_controller::on_btnOpen_clicked()
{
    connect_thread->openClient(QUrl(ui->editUrl->text()));
}

void administrator_controller::subWindowClosed()
{
    timer->stop();  // 关闭子窗口停止计时器
    connect_thread->closeClient();
    this->show();
}

void administrator_controller::on_PowerOn()
{
    emit signal_PowerOn();
}

// 发送空调主机设定好的参数到服务器
void administrator_controller::on_setPara(int Mode, int DefaultTargetTemp,int TempHighLimit, int TempLowLimit, double FeeRateH, double FeeRateM, double FeeRateL,int DefaultSpeed)
{
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType", MSG_TYPE_SETPARA);
    jsonMessage.insert("Mode", QString::number(Mode, 10));
    jsonMessage.insert("DefaultTemp", QString::number(DefaultTargetTemp, 10));
    jsonMessage.insert("HighestTemp", QString::number(TempHighLimit, 10));
    jsonMessage.insert("LowestTemp", QString::number(TempLowLimit, 10));
    jsonMessage.insert("HighFee", QString::number(FeeRateH, 'f', 1.0));
    jsonMessage.insert("MidFee", QString::number(FeeRateM, 'f', 0.5));
    jsonMessage.insert("LowFee", QString::number(FeeRateL, 'f', 0.33333));
    jsonMessage.insert("DefaultFanSpeed", QString::number(DefaultSpeed, 10));
    jsonMessage.insert("FeeRate", QString::number(FeeRateL, 'f', 1.0));

    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
    connect_thread->sendMessage(strJson);
}

void administrator_controller::on_StartUp()
{
    emit signal_StartUp();
}

// 发送查询房间空调状态
void administrator_controller::on_CheckRoomState()
{
    // 给服务器发包
    timer->start(1000);  // 每一秒刷新一次
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType", MSG_TYPE_CHECKROOMSTATE);

    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
    connect_thread->sendMessage(strJson);
}

// 对从服务器接收到的报文进行解析
void administrator_controller::messageFromServer(QString message)
{
//    emit signal_ClearContext();  // 每次接收到新的json包就先把旧表格清空
    qDebug() << "rec:" << message;
    QJsonObject jsonMessage = String2Json(message);
    if (jsonMessage.contains("MsgType"))
    {
        QJsonValue value = jsonMessage.value("MsgType");  // 获取指定key对应的value
        QJsonValue inf;
        int msgType = value.toInt();

        switch (msgType)
        {
        case MSG_TYPE_SETPARA:
            if (jsonMessage.contains("Ack"))
            {
                emit signal_setPara();
            }
            break;
        case MSG_TYPE_CHECKROOMSTATE:
            if (jsonMessage.contains("Data"))
            {
                QJsonValue allRooms = jsonMessage.value("Data");
                QJsonObject AllRooms = allRooms.toObject();
                int i = 1;

                emit signal_CheckRoomState(1, 31.5, 18, 2, 0.5, 1, 0, 100);

//                while (AllRooms.contains(QString::number(i, 10)))  // 根据json包中解析房间的具体参数
//                {
//                    QJsonValue ThisRoom = AllRooms.value(QString::number(i, 10));
//                    QJsonObject thisRoom = ThisRoom.toObject();
////                    inf = thisRoom.value("RoomId");
//                    mRoomId = i;
//                    inf = thisRoom.value("CurrentTemp");
//                    mRoomTemp = inf.toString().toDouble();
//                    inf = thisRoom.value("TargetTemp");
//                    mTargetTemp = inf.toString().toInt();
//                    inf = thisRoom.value("CurrentFanSpeed");
//                    mWindSpeed = inf.toString().toInt();
//                    inf = thisRoom.value("Fee");
//                    mMoney = inf.toString().toDouble();
//                    inf = thisRoom.value("Duration");
//                    mServiceDuration = inf.toString().toInt();
//                    inf = thisRoom.value("OriginTemp");
//                    int oriTemp = inf.toString().toInt();
////                    inf = thisRoom.value("WaitingDuration");
////                    mWaitingDuration = inf.toString().toInt();
//                    inf = thisRoom.value("CtState");
//                    mState = inf.toString().toInt();

//                    // 将解析到的数据传给UI层函数
//                    emit signal_CheckRoomState(mRoomId,mRoomTemp,mTargetTemp, mWindSpeed, mMoney,mServiceDuration,oriTemp,mState);
//                    i++;
//                }
            }
            else
            {
                // json包未含所需要的信息
                emit signal_CheckRoomState(-1,-1,-1,-1,-1,-1,-1,-1);
                qDebug() << "Server json error: do not have all required field(s)";
            }
            break;

        default:
            // 该json包的消息类型不存在
            qDebug() << "Server json error: do not have this msg type";
            break;
        }
    }
    else
    {
        QMessageBox::critical(NULL, "Error", "服务器数据异常或网络异常！");
        return;
    }
}
