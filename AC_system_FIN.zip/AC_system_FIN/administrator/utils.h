#ifndef UTILS_H
#define UTILS_H


#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <header.h>

QString getWindStr(int FanSpeed);
QString getModeStr(int Mode);
QString getStateStr(int State);
QJsonObject String2Json(const QString& str);
QString Json2String(const QJsonObject& json);

#endif // UTILS_H
