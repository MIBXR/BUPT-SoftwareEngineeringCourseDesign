#include "clientthread.h"

clientthread::clientthread()
{
    client = new QWebSocket();

    connect(client, &QWebSocket::connected, this, [=]() {
        emit sgn_connected();
        qDebug() << "Socket connected";
    });
    connect(client, &QWebSocket::disconnected, this, [=]() {
        emit sgn_disconnected();
        qDebug() << "Socket disconnected";
    });
    connect(client, &QWebSocket::textMessageReceived, this, [=](const QString& msg) {
        emit sgn_recvMessage(msg);
    });
}

void clientthread::openClient(QUrl url)
{
    client->open(url);
}

void clientthread::closeClient()
{
    client->close();
}

void clientthread::sendMessage(QString text)
{
    client->sendTextMessage(text);
}

QString clientthread::getAddress()
{
    return client->localAddress().toString();
}

QString clientthread::getPort()
{
    return QString::number(client->localPort());
}

clientthread::~clientthread()
{
}
