/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * administrator_window
 *
 * 模块功能:
 * 用于发送管理员请求的UI界面类
 *
 * Created on 2021/6/5.
 * @author hbw1112@foxmail.com (Huang Bowei)
 *
 * Edited on 2021/6/15.
 * @author hbw1112@foxmail.com (Huang Bowei)
 *
 */
#ifndef ADMINISTRATOR_WINDOW_H
#define ADMINISTRATOR_WINDOW_H

#include <QWidget>
#include <QDebug>
#include <QString>
#include <QCloseEvent>
#include <QMessageBox>
#include <header.h>
#include <utils.h>

namespace Ui {
class administrator_window;
}

class administrator_window : public QWidget
{
    Q_OBJECT

public:
    explicit administrator_window(QWidget *parent = nullptr);
    ~administrator_window();

private:
    Ui::administrator_window *ui;

signals:
    // 这里填UI层到控制器层的信号
    void signal_PowerOn();
    void signal_setPara(int Mode, int DefaultTargetTemp,int TempHighLimit, int TempLowLimit, double FeeRateH, double FeeRateM, double FeeRateL,int DefaultSpeed);
    void signal_StartUp();
    void signal_CheckRoomState();

    void signal_windowClose();

private slots:
    // 这里是UI按钮等控件的事件槽函数

    void on_powerOn_clicked();
    void on_setPara_clicked();
    void on_StartUp_clicked();
    void on_CheckRoomState_clicked();

public slots:
    // 这里填控制器层到UI层的消息对应的槽函数
    void on_PowerOn();
    void on_setPara();
    void on_StartUp();
    void on_CheckRoomState(int mRoomId , double mRoomTemp,int mTargetTemp , int mWindSpeed,
                           double mMoney , int mServiceDuration,int mWaitingDuration , int mState);
    void on_ClearContext();
protected:
    void closeEvent(QCloseEvent *event);  // 窗口关闭事件
};

#endif // ADMINISTRATOR_WINDOW_H
