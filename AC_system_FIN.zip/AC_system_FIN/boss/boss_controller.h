/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * boss_controller
 *
 * 模块功能:
 * 用于接收经理报表请求控制器类
 *
 * Created on 2021/6/9.
 * @author 1209618831@qq.com (Wang Qian)
 *
 * Edited on 2021/6/12.
 * @editer 1209618831@qq.com (Wang Qian)
 *
 */
#ifndef BOSS_CONTROLLER_H
#define BOSS_CONTROLLER_H

#include <QUrl>
#include <QWidget>
#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <clientthread.h>
#include <boss_window.h>
#include <string>
#include <fstream>
#include <iostream>
#include <QList>
#include <header.h>
#include "report.h"


QT_BEGIN_NAMESPACE
namespace Ui { class boss_controller; }
QT_END_NAMESPACE

class boss_controller : public QWidget
{
    Q_OBJECT

public:
    boss_controller(QWidget *parent = nullptr);
    ~boss_controller();


private:
    Ui::boss_controller *ui;
    clientthread* connect_thread;   // 通信实体
    boss_window* bossWindow;  // 界面实体
    Report* reportWindow;  // 报表实体
    


signals:
    // 这里为控制器层到UI层的信号：
    void signal_BeginRequest();  // 请求查询报表
    void signal_PrintReport();  // 请求打印报表
    void signal_ClearReport();  // 清除报表
    void signal_CreateReport(int mRoomId, int mOpenTime, int mDispatchTime,
                                 int mDetailNum, int mWindChangeNum, int mServiceTime, double mTotalFee);  // 创建报表对象

private slots:
    // 这里是UI层到控制器层的消息对应的槽函数：
    void on_BeginRequest(int RoomId,int type_Report,int date1, int date2);
    void on_PrintReport(int ReportId, int date1, int date2);
    void on_Release_Report(int ReportId);

    // 这里是QT自动生成的槽函数
    void on_btnOpen_clicked();

    // 这里是其他槽函数
    void getReportId();
    void messageFromServer(QString message);  // 获取服务器端
    void subWindowClosed();  // 子界面关闭

};
#endif // BOSS_CONTROLLER_H
