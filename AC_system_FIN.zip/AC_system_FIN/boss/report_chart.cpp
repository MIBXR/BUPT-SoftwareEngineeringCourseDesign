#include "report_chart.h"
#include "ui_report_chart.h"

report_chart::report_chart(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::report_chart)
{
    ui->setupUi(this);
}

report_chart::~report_chart()
{
    delete ui;
}
