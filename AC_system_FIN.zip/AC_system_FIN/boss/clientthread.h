/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * clientthread
 *
 * 模块功能:
 * 用于通信
 *
 * Created on 2021/6/5.
 * @author mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/6/6.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 */
#ifndef clientthread_H
#define clientthread_H
#include <QDebug>
#include <QObject>
#include <QThread>
#include <QTime>
#include <QWidget>
#include <QtWebSockets>
#include <winsock2.h>

class clientthread : public QObject
{
    Q_OBJECT
public:
    clientthread();
    ~clientthread();

public:
    void openClient(QUrl url);
    void closeClient();
    void sendMessage(QString text);
    QString getAddress();
    QString getPort();

private:
    QString thread_msg;
    QWebSocket* client;

signals:
    void sgn_connected();
    void sgn_disconnected();
    void sgn_recvMessage(QString msg);
};

#endif // clientthread_H
