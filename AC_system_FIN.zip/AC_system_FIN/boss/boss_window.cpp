#include "boss_window.h"
#include "ui_boss_window.h"
#include "report_chart.h"
#include <QDebug>
#include "ui_report_chart.h"

boss_window::boss_window(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::boss_window)
{
    int date1;
    ui->setupUi(this);
    // 经理UI设置
    setWindowTitle(tr("boss"));
    ui->Daily->setEnabled(true);
    ui->Weekly->setEnabled(true);
    ui->Monthly->setEnabled(true);
    ui->DTstart->setEnabled(true);
    ui->DTend->setEnabled(true);
    ui->RequestBtn->setEnabled(true);
}

boss_window::~boss_window()
{
    delete ui;
}

void boss_window::closeEvent(QCloseEvent *event)
{
    emit signal_windowClose();
}

void boss_window::on_BeginRequest()
{
    emit signal_PrintReport(0,0,0);
}

void boss_window::on_PrintReport()
{

}

void boss_window::on_Release_Report()
{

}

void boss_window::on_RequestBtn_clicked()
{
    int type_Report;
    // 区分日、周、月报表类型
    if(ui->Daily->isChecked())
        type_Report = 1;
    else if(ui->Weekly->isChecked())
        type_Report = 2;
    else if(ui->Monthly->isChecked())
        type_Report = 3;

    emit signal_BeginRequest(0, type_Report, 0, 0);  // 向boss_controller发送报表请求信号
}
