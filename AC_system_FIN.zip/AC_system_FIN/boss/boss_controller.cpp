#include "boss_controller.h"
#include "ui_boss_controller.h"
#include "QDebug"

boss_controller::boss_controller(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::boss_controller)
{
    ui->setupUi(this);

    setWindowTitle(tr("loading..."));

    // 新建数据传输对象与操作界面对象
    connect_thread = new clientthread();
    bossWindow = new boss_window();
    reportWindow = new Report();

    connect(bossWindow, &boss_window::signal_windowClose, this, &boss_controller::subWindowClosed);

    // Socket连接状态
    connect(connect_thread, &clientthread::sgn_connected, this, [=]() {
        bossWindow->show();
        qDebug() << "Client connected";
        this->hide();
    });
    connect(connect_thread, &clientthread::sgn_disconnected, this, [=]() {
        qDebug() << "Client disconnected";
        this->show();
    });
    
    // 应用逻辑层到控制器层的消息（接收来自服务器的数据并处理）
    connect(connect_thread, &clientthread::sgn_recvMessage, this, &boss_controller::messageFromServer);

    // UI层到控制器层的消息
    connect(bossWindow, &boss_window::signal_BeginRequest, this, &boss_controller::on_BeginRequest);
    connect(bossWindow, &boss_window::signal_PrintReport, this, &boss_controller::on_PrintReport);
    connect(bossWindow, &boss_window::signal_ReleaseReport, this, &boss_controller::on_Release_Report);

    // 控制器层到UI层的消息
    connect(this, &boss_controller::signal_BeginRequest, bossWindow, &boss_window::on_BeginRequest);

    // 控制器层到报表对象
    connect(this, &boss_controller::signal_CreateReport, reportWindow, &Report::on_CreateReport);
    connect(this, &boss_controller::signal_ClearReport, reportWindow, &Report::on_ClearReport);
    connect(this, &boss_controller::signal_PrintReport, reportWindow, &Report::on_PrintReport);
}

boss_controller::~boss_controller()
{
    delete ui;
}

void boss_controller::getReportId()
{

}

void boss_controller::on_BeginRequest(int RoomId, int type_Report, int date1, int date2)
{
    // 请求服务器查询
    QJsonObject jsonMessage;
    jsonMessage.insert("MsgType", MSG_TYPE_BEGINREQUEST);

    QString strJson = Json2String(jsonMessage);
    qDebug() << "send: " << strJson;
    connect_thread->sendMessage(strJson);
    
}

void boss_controller::on_PrintReport(int ReportId, int date1, int date2)
{
    emit signal_PrintReport();
}

void boss_controller::on_btnOpen_clicked()
{
    connect_thread->openClient(QUrl(ui->editUrl->text()));
}


void boss_controller::messageFromServer(QString message)
{
    // 从服务器获取信息
    qDebug() << "rec:" << message;
    QJsonObject jsonMessage = String2Json(message);

    QJsonValue value = jsonMessage.value("MsgType");  // 获取指定key对应的value
    int roomId, openTime, dispatchTime, detailNum, windChangeNum, serviceTime;
    double totalFee;

    if (jsonMessage.contains("Report"))  // 当获取到的信息为报表时
    {
         emit signal_ClearReport();  // 清除上一次报表信息

        QJsonObject allReportItems = jsonMessage.value("Report").toObject();
        int i = 1;
        while (allReportItems.contains(QString::number(i, 10)))
        {
            QJsonObject ReportItem = allReportItems.value(QString::number(i, 10)).toObject();
            roomId = ReportItem.value("RoomId").toString().toInt();
            openTime = ReportItem.value("OpenTime").toString().toInt();
            dispatchTime = ReportItem.value("DispatchTime").toString().toInt();
            detailNum = ReportItem.value("DetailNum").toString().toInt();
            windChangeNum = ReportItem.value("WindChangeNum").toString().toInt();
            serviceTime = ReportItem.value("ServiceTime").toString().toInt();
            totalFee = ReportItem.value("TotalFee").toString().toDouble();

            qDebug()<<"RoomId:"<<roomId;
            qDebug()<<"Fee:"<<totalFee;
            emit signal_CreateReport(roomId, openTime, dispatchTime, detailNum, windChangeNum, serviceTime, totalFee);

            i++;
        }

             emit signal_BeginRequest();
        }
        
    else
    {
        QMessageBox::critical(NULL, "Error", "服务器数据异常或网络异常！");
        return;
    }
}

void boss_controller::on_Release_Report(int ReportId)
{

}

void boss_controller::subWindowClosed()
{
    connect_thread->closeClient();
    this->show();
}
