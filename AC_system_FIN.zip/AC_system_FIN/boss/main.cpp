#include "boss_controller.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    boss_controller w;
    w.show();
    return a.exec();
}
