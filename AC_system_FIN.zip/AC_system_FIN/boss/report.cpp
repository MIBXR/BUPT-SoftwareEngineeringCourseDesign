#include "report.h"
#include "QString"
#include <QTextStream>
#include <QList>
using namespace QtCharts;


Report::Report(QObject *parent) : QObject(parent)
{

}
void Report::Draw()  // 绘制报表数据图
{
    // 绘制饼图，通过该类调用report_chart类来展示数据图UI
    mychart = new report_chart();
    QChart* m_chart = new QChart();
    QPieSeries* m_series = new QPieSeries();


    for(int i=0;i<ReportList.length();i++)
    {
        if(i % 7 == 0)
            m_series->append(ReportList[i], ReportList[i+6].toDouble());  //获取报表房间号与费用的对应关系
    }
    QChartView *chartView = new QChartView(m_chart);

    chartView->chart()->setTheme(QChart::ChartThemeLight);
    chartView->chart()->setDropShadowEnabled(true);  // 背景阴影
    chartView->chart()->setTitle("房间总费用占比"); // 加入标题
    chartView->chart()->addSeries(m_series);  //加入数据
    chartView->chart()->legend()->setAlignment(Qt::AlignBottom);
    chartView->chart()->legend()->setBackgroundVisible(true);
    chartView->chart()->legend()->setAutoFillBackground(true);
    chartView->setRenderHint(QPainter::Antialiasing);  //呈现方式
    mychart->ui->PieWidget->setChart(m_chart);
    mychart->show();

    // 绘制条形图
    QChart* chart= new QChart();
    QBarSet* feeSet= new QBarSet("总费用");
    for(int i=0;i<ReportList.length();i++)
    {
        if(i%7 == 6)
            *feeSet << ReportList[i].toDouble();
    }
    feeSet->setLabelColor(QColor(0,0,255));

    QBarSeries *series = new QBarSeries();
    series->append(feeSet);
    series->setVisible(true);
    series->setLabelsVisible(true);

    chart->setTheme(QChart::ChartThemeLight);  // 设置白色主题
    chart->setDropShadowEnabled(true);  // 背景阴影
    chart->addSeries(series);  // 添加系列到QChart上

    chart->setTitleBrush(QBrush(QColor(0,0,255)));  // 设置标题Brush
    chart->setTitleFont(QFont("微软雅黑"));  // 设置标题字体
    chart->setTitle("房间总费用统计");

    QBarCategoryAxis *axisX = new QBarCategoryAxis;
    for(int i=0;i<ReportList.length();i++)
    {
         if(i%7 == 0)
             axisX->append(ReportList[i]);
    }
     QValueAxis *axisY = new QValueAxis;
     axisY->setRange(0,20);
     axisY->setTitleText("费用(单位:元)");
     axisY->setLabelFormat("%d");

     chart->setAxisX(axisX,series);
     chart->setAxisY(axisY,series);

     chart->legend()->setVisible(true);
     chart->legend()->setAlignment(Qt::AlignBottom);  // 底部对齐
     chart->legend()->setBackgroundVisible(true);  // 设置背景是否可视
     chart->legend()->setAutoFillBackground(true);  // 设置背景自动填充
     chart->legend()->setColor(QColor(222,233,251));  // 设置颜色
     chart->legend()->setLabelColor(QColor(0,100,255));  // 设置标签颜色
     mychart->ui->LineWidget->setChart(chart);
     mychart->show();

}
void Report::on_CreateReport(int mRoomId, int mOpenTime, int mDispatchTime,
                             int mDetailNum, int mWindChangeNum, int mServiceTime, double mTotalFee)
{
    // 创建报表对象
    ReportList.append(QString::number(mRoomId));
    ReportList.append(QString::number(mOpenTime));
    ReportList.append(QString::number(mDispatchTime));
    ReportList.append(QString::number(mDetailNum));
    ReportList.append(QString::number(mWindChangeNum));
    ReportList.append(QString::number(mServiceTime));
    ReportList.append(QString::number(mTotalFee));

}

void Report::on_PrintReport()
{
    // 打印报表，将报表输出到txt中
    QFile file("Report.txt");
    qDebug()<<"Qfile open!";
    if (!file.open(QFile::WriteOnly | QFile::Truncate))
    {
        qDebug()<<"cannot open the file!";
    }
    QTextStream out(&file);
    out <<tr("##########每个房间的报表如下#############\n");
    for(int i=0; i<ReportList.length();i++){

        switch (i%7) {
         case 0 : out <<tr("房间号：") << ReportList[i]<<"\n";break;
         case 1 : out <<tr("空调开关次数：")<<ReportList[i]<< "\n";break;
         case 2 :out <<tr("空调调度次数：")<<ReportList[i] << "\n";break;
         case 3 :out <<tr("详单个数：")<<ReportList[i] << "\n";break;
         case 4 :out <<tr("风速改变次数：")<<ReportList[i] << "\n";break;
         case 5 :out <<tr("服务次数：")<<ReportList[i] << "\n";break;
         case 6 :out <<tr("费用：")<<ReportList[i] << "\n";break;
         }
        if((i+1)%7 == 0)
            out <<tr("#########################################\n");
     }
    Draw();  // 画出报表数据图
    file.close();
}

void Report::on_ClearReport()
{
    // 清除报表中的内容
    ReportList.clear();
}

Report::~Report(){

}
