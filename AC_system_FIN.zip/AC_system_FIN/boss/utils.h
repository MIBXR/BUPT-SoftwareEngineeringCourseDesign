/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * utils
 *
 * 模块功能:
 * 用于转换风速、状态等值为string类型
 *
 * Created on 2021/6/5.
 * @author mibxr@bupt.edu.cn (Xie Rui)
 *
 * Edited on 2021/6/6.
 * @editer mibxr@bupt.edu.cn (Xie Rui)
 *
 */
#ifndef UTILS_H
#define UTILS_H


#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <header.h>

QString getWindStr(int FanSpeed);
QString getModeStr(int Mode);
QString getStateStr(int State);
QJsonObject String2Json(const QString& str);
QString Json2String(const QJsonObject& json);

#endif // UTILS_H
