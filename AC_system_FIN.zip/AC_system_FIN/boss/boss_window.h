/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * boss_window
 *
 * 模块功能:
 * 用于接收经理报表请求窗口
 *
 * Created on 2021/6/9.
 * @author 1209618831@qq.com (Wang Qian)
 *
 * Edited on 2021/6/12.
 * @editer 1209618831@qq.com (Wang Qian)
 *
 */
#ifndef BOSS_WINDOW_H
#define BOSS_WINDOW_H

#include <QWidget>
#include <QDebug>
#include <QCloseEvent>
#include <QMessageBox>
#include <header.h>
#include <utils.h>
#include "report_chart.h"
#include "ui_report_chart.h"
#include "report.h"
#include <QChartView>
#include <QChart>
#include <QWidget>
#include <QtCharts>
QT_CHARTS_USE_NAMESPACE

namespace Ui {
class boss_window;
}


class boss_window : public QWidget
{
    Q_OBJECT

public:
    explicit boss_window(QWidget *parent = nullptr);

    ~boss_window();


private:
    Ui::boss_window *ui;


signals:
    // 这里填UI层到控制器层的信号
    void signal_BeginRequest(int RoomId,int type_Report,int date1, int date2);
    void signal_PrintReport(int ReportId, int date1, int date2);
    void signal_ReleaseReport(int ReportId);
    void signal_windowClose();

private slots:
    // 这里是UI按钮等控件的事件槽函数    
    void on_RequestBtn_clicked();
    
public slots:
    // 这里填控制器层到UI层的消息对应的槽函数，控制器返回过来
    void on_BeginRequest();  //请求查询报表
    void on_PrintReport();  // 打印报表
    void on_Release_Report();  // 释放报表

protected:
    void closeEvent(QCloseEvent *event);   // 窗口关闭事件
};

#endif // BOSS_WINDOW_H
