/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * report_chart
 *
 * 模块功能:
 * 用于画出报表的数据图（饼图、条形图）
 *
 * 本模块需要在QT上添加新组件QChart，否则程序将会报错
 *
 * Created on 2021/6/9.
 * @author 1209618831@qq.com (Wang Qian)
 *
 * Edited on 2021/6/12.
 * @editer 1209618831@qq.com (Wang Qian)
 *
 */
#ifndef REPORT_CHART_H
#define REPORT_CHART_H

#include <QWidget>
#include <QtCharts>

namespace Ui {
class report_chart;
}

class report_chart : public QWidget
{
    Q_OBJECT

public:
    explicit report_chart(QWidget *parent = 0);
    ~report_chart();
    Ui::report_chart *ui;

private:

};

#endif // REPORT_CHART_H
