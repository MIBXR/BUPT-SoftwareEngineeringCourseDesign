/**
 * 版本号:
 * @version v2.8.9
 *
 * 类名:
 * report
 *
 * 模块功能:
 * 报表类，可创建报表对象
 *
 * 本模块需要在QT上添加新组件QChart，否则程序将会报错
 *
 * Created on 2021/6/9.
 * @author 1209618831@qq.com (Wang Qian)
 *
 * Edited on 2021/6/12.
 * @editer 1209618831@qq.com (Wang Qian)
 *
 */
#ifndef REPORT_H
#define REPORT_H

#include <QDebug>
#include <QObject>
#include "report_chart.h"
#include "ui_report_chart.h"
#include "header.h"
#include <QFile>
#include <QtCharts>
#include <QChartView>

QT_CHARTS_USE_NAMESPACE

class Report : public QObject
{
    Q_OBJECT
public:
    Report(QObject *parent = nullptr);
    ~Report();

    QList<QString> ReportList;  // 报表对象为列表形式
    report_chart *mychart;  // report_chart界面实体

    void Draw();

signals:

public slots:
    // 报表槽函数
    void on_PrintReport(); // 打印报表
    void on_CreateReport(int mRoomId, int mOpenTime, int mDispatchTime,
                         int mDetailNum, int mWindChangeNum, int mServiceTime, double mTotalFee);  // 创造报表

    void on_ClearReport();  // 清除报表

private:
    // 报表属性
    int RoomId;
    int OpenTime;
    int DispatchTime;
    int DetailNum;
    int WindChangeNum;
    int ServiceTime;
    double TotalFee;
};

#endif // REPORT_H
